-- MySQL dump 10.13  Distrib 5.6.46, for Linux (x86_64)
--
-- Host: localhost    Database: blog_data
-- ------------------------------------------------------
-- Server version	5.6.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article_articlecolumn`
--

DROP TABLE IF EXISTS `article_articlecolumn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_articlecolumn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `created` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_articlecolumn`
--

LOCK TABLES `article_articlecolumn` WRITE;
/*!40000 ALTER TABLE `article_articlecolumn` DISABLE KEYS */;
INSERT INTO `article_articlecolumn` VALUES (1,'程序人生','2019-11-29 02:55:03.000000'),(2,'工作/生活','2019-11-29 02:55:27.000000');
/*!40000 ALTER TABLE `article_articlecolumn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article_articlepost`
--

DROP TABLE IF EXISTS `article_articlepost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_articlepost` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `body` longtext NOT NULL,
  `created` datetime(6) NOT NULL,
  `updated` datetime(6) NOT NULL,
  `author_id` int(11) NOT NULL,
  `total_views` int(10) unsigned NOT NULL,
  `column_id` int(11) DEFAULT NULL,
  `likes` int(10) unsigned NOT NULL,
  `avatar` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `article_articlepost_author_id_b855d44d_fk_auth_user_id` (`author_id`),
  KEY `article_articlepost_column_id_48f69d78_fk_article_a` (`column_id`),
  CONSTRAINT `article_articlepost_author_id_b855d44d_fk_auth_user_id` FOREIGN KEY (`author_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `article_articlepost_column_id_48f69d78_fk_article_a` FOREIGN KEY (`column_id`) REFERENCES `article_articlecolumn` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_articlepost`
--

LOCK TABLES `article_articlepost` WRITE;
/*!40000 ALTER TABLE `article_articlepost` DISABLE KEYS */;
INSERT INTO `article_articlepost` VALUES (1,'美丽的家乡-六盘水','#### 一、地理位置\r\n六盘水市，是贵州省的6个地级市之一，驻地钟山区。别称中国凉都。 [1]  位于贵州西部乌蒙山区，年平均气温15℃，夏季平均气温19.7℃，冬季平均气温3℃。气候凉爽、舒适、滋润、清新，紫外线辐射适中，被中国气象学会授予“中国凉都”称号，是全国唯一以气候特征命名的城市。 [2] \r\n六盘水春秋时期为牂牁国属地；战国时期，市境内为夜郎国属地，由于金属工具的使用，已进入了农耕时代，并反映奴隶制生产关系的特征；秦统一中国后，为巴郡汉阳县属地。\r\n六盘水地处滇、黔两省结合部，长江、珠江上游分水岭，南盘江、北盘江流域两岸，矿产资源十分丰富。交通四通八达，是西南重要的铁路枢纽城市和物流集散中心之一。截至2016年末，全市国土面积9965平方公里，辖2个区、1个县级市、1个县，常住人口290.7万。\r\n#### 二、历史文化\r\n- 1978年12月，地区改为省辖市，市革命委员会驻水城特区。\r\n- 1987年12月，国务院批准撤消水城特区，分设钟山区、水城县。市人民政府驻钟山区。\r\n- 1999年2月，国务院批准撤消盘县特区，设立盘县，以原盘县特区行政区域为盘县行政区域。县人民政府驻红果镇。至此，六盘水市辖一特区两县一区，为六枝特区、盘县、水城县、钟山区。[5]\r\n- 2017年11月9日，贵州省人民政府正式签发《省人民政府关于同意钟山区凤凰街道石龙村、石桥社区、双龙社区划归水城县双水街道管辖的批复》（黔府函〔2017〕222号），批复：同意将钟山区凤凰街道石龙村、石桥社区、双龙社区划归水城县双水街道管辖。[6]1978年12月，地区改为省辖市，市革命委员会驻水城特区。\r\n- 1987年12月，国务院批准撤消水城特区，分设钟山区、水城县。市人民政府驻钟山区。\r\n- 1999年2月，国务院批准撤消盘县特区，设立盘县，以原盘县特区行政区域为盘县行政区域。县人民政府驻红果镇。至此，六盘水市辖一特区两县一区，为六枝特区、盘县、水城县、钟山区。[5]\r\n- 2017年11月9日，贵州省人民政府正式签发《省人民政府关于同意钟山区凤凰街道石龙村、石桥社区、双龙社区划归水城县双水街道管辖的批复》（黔府函〔2017〕222号），批复：同意将钟山区凤凰街道石龙村、石桥社区、双龙社区划归水城县双水街道管辖。[6]\r\n#### 三、旅游观光\r\n- 乌蒙大草原\r\n乌蒙大草原当地人也称为坡上草原，位于盘县北部，距县城89公里。乌蒙大草原属盘北高海拔区，最高海拔2857米（贵州第二高）、最低740米，为高原山地地貌，以玄武岩、岩溶地貌为主，平均气温11.1℃，气候凉爽，居住有较多的彝、白、苗、布依等少数民族。 乌蒙大草原由万亩坡上草原牧场、万亩矮杜鹊林、沙河龙潭口溶洞、天生桥、格所河峡谷大出水洞、天然大天窗等资源为主组成，还包括有古榕树群、草原湖泊、千亩杜鹊林、千亩天然林、龙天佑古墓、彝族村寨、彝族“火把节”、白族“火把节”以及岩溶峰林、峰丛等自然风光、人文景观景点42个，资源丰富。 有关景物相对集中地分布在盘北的四格坡上，淤泥、沙河、保基格所河三大片区大约260平方公里，风景名胜区中自然环境较好，植被覆盖率高。这里水源清澈、空气新鲜。\r\n- 韭菜坪\r\n韭菜坪: 位于钟山区大湾镇海戛村，山上长有野韭菜，山脊和侧坡上呈现一处处缓平地带，故名。主峰距中心城西北约90公里，海拔2900.3米，为贵州省最高峰，素有“贵州屋脊”之称。韭菜坪梁子呈西北东南走向，南坡缓长，北坡陡短。梁子岭脉亘于群峰之上，为四周群峰簇拥，峰上有峰，岭外有岭。\r\n- 妥乐古银杏村\r\n世界古银杏之乡特指中国贵州省盘县石桥镇妥乐古银杏村。妥乐古银杏村位于有中国凉都之称的贵州省六盘水市盘县石桥镇的妥乐村，这里流水潺潺，古树绵绵，小桥映虹，奇峰傍寺，是贵州省著名的风景名胜区。全村生长了1450多株连片成林的古银杏林，一般树龄在300年以上，最长者有1200余年，植株高大，胸径一般在100—200cm，最大220cm，树冠高度15—30米，是世界上古银杏生长密度最大、保存最完好的地方，享有”世界古银杏之乡“的盛誉。妥乐古银杏风景区处在盘县古银杏风景名胜区的中心地带，主景区内有第四纪冰川期孑遗的古银杏1450株，是全世界古银杏最集中的地方[1] ，形成世界上十分罕见的博大精深的“人树相依”的树文化，素有“世界活化石基地”之称。','2019-11-29 02:55:53.000000','2019-12-04 08:37:16.996442',1,199,2,22,''),(2,'关于Nginx报错500的问题','Django网站部署上线后，想着sqlite3已经不太适用于线上环境了，于是打算换上Mysql用于线上环境，但是其中过程真可谓是一步一个坑。从安装开始就频频报错。额....回到正题,，关于MYSQL报错500 Internal Server Error的问题。\r\n这个问题的产生主要归结于，我们没有正确的设置好编码utf8，也就是创建数据库的时候，没有指定数据库的默认编码方式，数据库就默认用了Latin，这样导致我们写入中文的时候会产生报错，查了很多资料找到两种解决办法，\r\n<p>\r\n - 第一种就是，创建数据库时，直接设定编码方式。</P>\r\n<p>\r\n - 第二种就是，更改表的字段编码方式。</p>\r\n\r\n<pre>\r\n<code class=\"language-python\">\r\n#我一开始也是省略了这个，导致后面出了一大堆问题\r\nCREATE DATABASE mysite CHARACTER SET utf8;  \r\n#使用这条语句来查看表的编码方式\r\nshow create table tablename; \r\n#使用这条语句来修改字段的编码方式\r\nalter table tablename change fieldname fieldname  varchar(60) character set utf8;  </code></pre>','2019-11-29 03:16:52.462970','2019-12-12 09:01:54.533663',1,79,1,0,''),(4,'Django配置MYSQL数据库','<p>在实际生产环境，Django是不可能使用SQLite这种轻量级的基于文件的数据库作为生产数据库。一般较多的会选择MySQL。</p>\r\n\r\n<p>下面介绍一下如何在Django中使用MySQL数据库。</p>\r\n\r\n<p>一、安装MySQL</p>\r\n\r\n<p>不建议在Windows中部署MySQL，建议迁移到Linux上来。</p>\r\n\r\n<p>我这里使用的是ubuntu16.04。</p>\r\n\r\n<p>安装命令：</p>\r\n\r\n<pre>\r\n<code class=\"language-bash\">sudo apt-get update\r\nsudo apt-get install mysql-server mysql-client\r\n</code></pre>\r\n\r\n<p>中途，请设置root用户的密码。</p>\r\n\r\n<p>安装完毕后，使用命令行工具，输入root的密码，进入mysql：</p>\r\n\r\n<pre>\r\n<code class=\"language-bash\">mysql -u root -p\r\n</code></pre>\r\n\r\n<p>提示如下：</p>\r\n\r\n<pre>\r\n<code class=\"language-bash\">[feixue@feixue-VirtualBox: ~]$ mysql -u root -p\r\nEnter password: \r\nWelcome to the MySQL monitor.  Commands end with ; or \\g.\r\nYour MySQL connection id is 4\r\nServer version: 5.7.20-0ubuntu0.16.04.1 (Ubuntu)\r\n\r\nCopyright (c) 2000, 2017, Oracle and/or its affiliates. All rights reserved.\r\n\r\nOracle is a registered trademark of Oracle Corporation and/or its\r\naffiliates. Other names may be trademarks of their respective\r\nowners.\r\n\r\nType &#39;help;&#39; or &#39;\\h&#39; for help. Type &#39;\\c&#39; to clear the current input statement.\r\n\r\nmysql&gt; \r\n</code></pre>\r\n\r\n<p>可以使用命令，先看看当前数据库系统内有哪些已经默认创建好了的数据库：</p>\r\n\r\n<pre>\r\n<code class=\"language-bash\">mysql&gt; SHOW DATABASES;\r\n+--------------------+\r\n| Database           |\r\n+--------------------+\r\n| information_schema |\r\n| mysql              |\r\n| performance_schema |\r\n| sys                |\r\n+--------------------+\r\n4 rows in set (0.04 sec)\r\n</code></pre>\r\n\r\n<p>假设我们的Django工程名字为&#39;mysite&#39;，那么我们就创建一个mysite数据库，当然，名字其实随意，但是一样的更好记忆和区分，不是么？</p>\r\n\r\n<pre>\r\n<code class=\"language-bash\">CREATE DATABASE mysite CHARACTER SET utf8;\r\n</code></pre>\r\n\r\n<p>强调：一定要将字符编码设置为utf8，很多错误就是没正确设置编码导致的！</p>\r\n\r\n<p>创建好mystie数据库后，可以用上面的命令，检查一下，没有问题，就退出mysql。</p>\r\n\r\n<pre>\r\n<code class=\"language-bash\">mysql&gt; CREATE DATABASE mysite CHARACTER SET utf8;\r\nQuery OK, 1 row affected (0.00 sec)\r\n\r\nmysql&gt; SHOW DATABASES;\r\n+--------------------+\r\n| Database           |\r\n+--------------------+\r\n| information_schema |\r\n| mysite             |\r\n| mysql              |\r\n| performance_schema |\r\n| sys                |\r\n+--------------------+\r\n5 rows in set (0.00 sec)\r\n\r\nmysql&gt; exit;\r\nBye\r\n</code></pre>\r\n\r\n<p>二、配置MySQL服务</p>\r\n\r\n<p>由于我的环境是局域网，Django项目所在主机为192.168.1.100，而mysql所在linux为虚拟机，IP为192.168.1.121，为了能够从项目主机访问数据库主机，需要对MySQL服务进行配置。</p>\r\n\r\n<p>打开配置文件：</p>\r\n\r\n<pre>\r\n<code class=\"language-bash\">sudo vim /etc/mysql/mysql.conf.d/mysqld.cnf\r\n</code></pre>\r\n\r\n<p>将下面一行注释掉：</p>\r\n\r\n<pre>\r\n<code class=\"language-bash\"># band-address = localhost\r\n</code></pre>\r\n\r\n<pre>\r\n<code class=\"language-bash\"># .....\r\n\r\n[mysqld]\r\n#\r\n# * Basic Settings\r\n#\r\nuser            = mysql\r\npid-file        = /var/run/mysqld/mysqld.pid\r\nsocket          = /var/run/mysqld/mysqld.sock\r\nport            = 3306\r\nbasedir         = /usr\r\ndatadir         = /var/lib/mysql\r\ntmpdir          = /tmp\r\nlc-messages-dir = /usr/share/mysql\r\nskip-external-locking\r\n#bind-address= localhost\r\nskip-name-resolve\r\ncharacter-set-server=utf8\r\n\r\n# .....\r\n</code></pre>\r\n\r\n<p>如果不这么做，将会出现<code>error：1045 deny access</code>，拒绝访问错误。</p>\r\n\r\n<p>使用下面的命令，重新启动mysql服务：</p>\r\n\r\n<pre>\r\n<code class=\"language-bash\">sudo service mysql restart\r\n</code></pre>\r\n\r\n<p>三、安装Python访问MySQL的模块</p>\r\n\r\n<p>我使用的是Python3.6版本。由于mysqldb-python这个模块不支持Python3.4以上版本，因此只能安装pymysql库。</p>\r\n\r\n<pre>\r\n<code class=\"language-bash\">pip install pymysql\r\n</code></pre>\r\n\r\n<p>四、配置Django的settings.py</p>\r\n\r\n<p>在Django的settings.py文件中设置如下：</p>\r\n\r\n<pre>\r\n<code class=\"language-bash\">import pymysql         # 一定要添加这两行！           \r\npymysql.install_as_MySQLdb()\r\nDATABASES = {\r\n    &#39;default&#39;: {\r\n        &#39;ENGINE&#39;: &#39;django.db.backends.mysql&#39;,   # 数据库引擎\r\n        &#39;NAME&#39;: &#39;mysite&#39;,  # 数据库名，先前创建的\r\n        &#39;USER&#39;: &#39;root&#39;,     # 用户名，可以自己创建用户\r\n        &#39;PASSWORD&#39;: &#39;****&#39;,  # 密码\r\n        &#39;HOST&#39;: &#39;192.168.1.121&#39;,  # mysql服务所在的主机ip\r\n        &#39;PORT&#39;: &#39;3306&#39;,         # mysql服务端口\r\n    }\r\n}\r\n</code></pre>\r\n\r\n<p>重点是开始的两行！一定要添加，一定要这么写！</p>\r\n\r\n<p>至此，就可以像使用SQLite一样使用MySQL了！</p>','2019-12-04 08:24:14.415380','2019-12-18 06:24:55.992633',1,72,1,0,''),(5,'年底学习总结概要','<p>七月份毕业，转眼间已经踏入社会半年了，在这半年里，感觉收获了许多东西，也结识了很多新的朋友。在这即将过去的2019年，我觉得是时候总结一下这半年来的收获了，一来巩固一下所学的知识；二来借此发现自己的不足，加以强化。</p>\r\n\r\n<blockquote>\r\n<p>&nbsp;一切首先是从搭建网站开始，从这样一个完整的项目中，逐渐完善自己的知识体系。</p>\r\n</blockquote>\r\n\r\n<p><strong>一、Django</strong></p>\r\n\r\n<p>1.MTV流程</p>\r\n\r\n<blockquote>\r\n<ul>\r\n	<li>Django基础运作流程，M指的是模型model，主要是数据类型，通过模型，我们可以定义我们网站的数据库。</li>\r\n	<li>T指的是模板template,求出来的数据，让数据更加美观的呈现出来。</li>\r\n	<li>V指的是视图views,主要用于处理数据请求的逻辑。根据客户请求，提供相应的数据。</li>\r\n</ul>\r\n</blockquote>\r\n\r\n<p>2.如何写模型</p>\r\n\r\n<blockquote>\r\n<ul>\r\n	<li>模型主要是定义我们需要使用到的数据的数据类型、数据结构以及数据之间的关联关系。看个例子:</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-python\">from django.db import models\r\nfrom django.contrib.auth.models import User\r\nfrom django.utils import timezone\r\nclass ArticlePost(models.Model):\r\n    author = models.ForeignKey(User, on_delete=models.CASCADE)\r\n    title = models.CharField(max_length=100)\r\n    body = models.TextField()\r\n    created = models.DateTimeField(default=timezone.now)\r\n    updated = models.DateTimeField(auto_now=True)</code></pre>\r\n\r\n<p>&nbsp;</p>\r\n</blockquote>\r\n\r\n<p>3.如何写模板</p>\r\n\r\n<blockquote>\r\n<ul>\r\n	<li>模板主要是前端写作，但是Django有自己独特的数据展示方法，比如说：</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-python\">{{ variable }} #变量\r\n{{ value|default:\"nothing\" }} #过滤器\r\n\r\n#一个for循环\r\n{% for athlete in athlete_list %}\r\n    &lt;li&gt;{{ athlete.name }}&lt;/li&gt;\r\n{% endfor %}\r\n\r\n#一个if判断\r\n{% if athlete_list %}\r\n    Number of athletes: {{ athlete_list|length }}\r\n{% elif athlete_in_locker_room_list %}\r\n    Athletes should be out of the locker room soon!\r\n{% else %}\r\n    No athletes.\r\n{% endif %}\r\n\r\n{% extends \"base.html\" %} #模板的继承\r\n{% include \"template.html\" %} #插入模板内容\r\n{% block title %}This &amp;amp; that{% endblock %} #模板的标题\r\n{% block content %}{{ greeting }}{% endblock %} #模板的内容</code></pre>\r\n\r\n<p>&nbsp;</p>\r\n</blockquote>\r\n\r\n<p>4.如何写视图</p>\r\n\r\n<blockquote>\r\n<ul>\r\n	<li>视图用于调用数据库的数据满足用户的请求，当然用户的请求通过url连接模板和视图。下面看个简单的视图。</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-python\">#基于函数\r\ndef article_example(request):\r\n    articles = ArticlePost.objects.all()\r\n    context = {\'articles\': articles}\r\n    return render(request, \'article/list.html\', context)\r\n\r\n#基于类的视图\r\nfrom django.views.generic import ListView\r\n\r\nclass ArticleListView(ListView):\r\n    context_object_name = \'articles\'\r\n    queryset = ArticlePost.objects.all()\r\n    template_name = \'article/list.html\'</code></pre>\r\n\r\n<p>&nbsp;</p>\r\n</blockquote>\r\n\r\n<p><strong>二、Bootstrap+css+html前端工具</strong></p>\r\n\r\n<p>1.Bootstrap基础样式、布局</p>\r\n\r\n<blockquote>\r\n<ul>\r\n	<li>弹性布局</li>\r\n	<li>基础样式及组件</li>\r\n</ul>\r\n</blockquote>\r\n\r\n<p>2.CSS简单运用</p>\r\n\r\n<blockquote>\r\n<ul>\r\n	<li>style position 以及一些鼠标事件</li>\r\n</ul>\r\n</blockquote>\r\n\r\n<p>3.HTML简单运用</p>\r\n\r\n<blockquote>\r\n<ul>\r\n	<li>HTML基础表达</li>\r\n</ul>\r\n</blockquote>\r\n\r\n<p><strong>三、Linux学习</strong></p>\r\n\r\n<ol>\r\n	<li>Linux的常用命令</li>\r\n	<li>Linux系统服务、进程查询管理</li>\r\n	<li>vim生存级别操作</li>\r\n</ol>\r\n\r\n<p><strong>四、初识Docker</strong></p>\r\n\r\n<ol>\r\n	<li>docker基础操作</li>\r\n	<li>创建拉取容器、镜像</li>\r\n	<li>docker-compose编排多个镜像</li>\r\n</ol>\r\n\r\n<p><strong>五、基于nginx的部署，nginx相关配置</strong></p>\r\n\r\n<ol>\r\n	<li>nginx配置文件的更改</li>\r\n	<li>nginx如何配置ssl</li>\r\n</ol>\r\n\r\n<p><strong>六、拿来即用的supervior以及Gunicorn</strong></p>\r\n\r\n<ol>\r\n	<li>利用supervior管理部署网站的进程</li>\r\n	<li>利用Gunicorn处理动态请求</li>\r\n</ol>\r\n\r\n<p><strong>七、实用的Git</strong></p>\r\n\r\n<ol>\r\n	<li>Git常用操作</li>\r\n	<li>暂时未使用但常用的操作</li>\r\n</ol>\r\n\r\n<p><strong>八、Django使用数据库MYSQL&nbsp;</strong></p>\r\n\r\n<ol>\r\n	<li>CENTOS下如何安装使用MySQL</li>\r\n	<li>MySQL的基础操作</li>\r\n	<li>给网站换上MySQL</li>\r\n</ol>','2019-12-05 02:45:19.981170','2019-12-05 03:02:28.613117',1,80,1,1,''),(6,'虚无的十字架书评','<p>虚无的十字架，或许人无法做出完美的审判。又是一个很好的，新奇的，值得深思的立意。&nbsp;<br />\r\n刚开始以为只是单纯的表面那样的杀人案，可是后面才慢慢发现，果然是东野圭吾，不到最后，就不知道结局，真相永远不是表面那么简单。<br />\r\n这次还讲到了很多两个人之间的故事。这边就不直接说感想了，直接说故事就会明白了。井口沙织，她很爱仁科史也，无论出什么事都自己一个人承担，害怕给他遭成麻烦。最后，面临中考的她怀了已经上了高中的仁科史也的孩子，直到那个时候，为了不给他带来麻烦，她还是隐瞒他。最后，当然，仁科史也知道了。但是那个时候要打掉已经来不及了。她选择先把孩子生下来。直到生孩子的时候仁科史也提出要陪在她身边的时候，她，很难理解她是对他心怀感激的。孩子刚生下来他们俩就把孩子捂死埋掉了。半年不到他们也分手了。二十一年过去了，井口沙织一直活在阴暗里。而仁科史也，早已有了工作，房子，妻子，家庭。她的这种可以说是卑微的爱，真的是爱吗？我一直觉得爱是存在于双方的。而仁科史也对井口沙织有爱吗？不管怎样全文我没有看到他的任何负责任的地方。<br />\r\n中原夫妇经历了八岁女儿被杀的痛苦经历。那之后不久也离婚了。当然两者以后都深陷痛苦之中。中原一直强制自己不要回忆以前女儿在的快乐时光想要以此忘掉过去，开始新生活。而他的妻子，滨冈小夜子，开始了写稿，访谈的道路。因为有了这样的经历，她不希望自己的痛苦继续发生她一直坚定的拼搏着，文中也多次提到她说话时的语气，眼神。最后，小夜子在这条追寻&ldquo;真理&rdquo;的路上失去了她的生命&hellip;&hellip;<br />\r\n<br />\r\n花慧对丈夫仁科史也，我的确不知道是不是爱，或许更多是感激，感激他在她被骗了怀孕的时候娶了她。一直以来，被一个很优秀的丈夫当作是妻子一样对待。在知道丈夫仁科史也和井口沙织的事情的时候，这么多年了也终于为何当年娶她的理由的时候。她竟没有因为不是爱情而娶她而感到懊恼而是觉得丈夫娶她是为了赎罪这种人格是高尚的。或许和她之前没有被好好爱过有关，但还是搞不懂。<br />\r\n没有爱的两个人在一起可以长久吗？可以幸福吗？<br />\r\n最后还是要回到本文的宗旨，什么样的刑法才是最好的解决办法。</p>\r\n\r\n<p>本文有两个观点：</p>\r\n\r\n<p><strong>一、 不该废除死刑。</strong></p>\r\n\r\n<ol>\r\n	<li>杀了人之后的凶手没有理由再或许在监狱里像其他人一样吃饭，睡觉&nbsp;甚至还有自己的兴趣。</li>\r\n	<li>为什么杀人不该偿命。为什么受害者家属的痛苦没有人去了解和同情。</li>\r\n	<li>死刑可以避免没有被判死刑的凶手再次犯案的几率。小夜子的孩子就是凶手的再次犯案，如果第一次杀人的时候就已经被判死刑，就没有后面的悲剧。</li>\r\n</ol>\r\n\r\n<p><strong>二、 应该废除死刑。</strong></p>\r\n\r\n<p>被判死刑的杀死小夜子孩子的凶手只是觉得反正迟早都要死到死了都没有任何悔改之意，也没有任何愧疚。</p>\r\n\r\n<p>另一个案子中的仁科史也虽然没有得到法律的制裁但是身心却一直遭受痛苦，为了二十一年前的错，之后也为之做了很多。最后他们杀人的证据，孩子的遗骨没有找到，或许，作者的意图也大概这样。<br />\r\n<br />\r\n和之前看的X的悲剧的感觉一样，场景的随时切换。有时候还不忘调皮一下卖关子。</p>\r\n\r\n<p>该不该废除死刑，孩子和前妻的不幸，凶手的不同态度巧妙的做了对比。作者最后也没有直接给出确定的答案。这也是一个没有答案的问题。<img alt=\"devil\" src=\"https://liganggooo.com/static/ckeditor/ckeditor/plugins/smiley/images/devil_smile.png\" style=\"height:23px; width:23px\" title=\"devil\" /></p>','2019-12-05 02:54:11.449242','2019-12-18 12:13:38.811199',1,86,2,1,''),(7,'Simple is better than complex','<p style=\"font-size:20px;\"><b>\"</b>At the beginning of the development of the site, always feel to add a lot of style, will be beautiful, later found, simple will be beautiful.<b>\"</b></p>\r\n<p>网站开发了那么久了，在UI上花费的时间其实是最多的，从零基础到熟练的使用HTML+CSS，也不能说是熟练；主要是对于Bootstrap的运用。</p>\r\n\r\n<p class=\"text-center\"><img alt=\"\" src=\"http://code.z01.com/v4/assets/img/bootstrap-stack.png\" style=\"height:126px; width:150px\" /></p>\r\n\r\n<p>Bootstrap的是款现如今不叫流行的框架，它集成了很多常用的、比较经典的样式。能够满足我们的一些日常使用。接触了bootstrp以后感觉就一发不可收拾了，对于上面的样式有点滥用的感觉，弄得整个界面花里胡哨的，觉得很好看；现在才发现，简洁的才是最好看的。引用python之禅上的话就是，Simple is better than complex。</p>\r\n\r\n<p>但是还是可以聊聊Bootstrap：</p>\r\n\r\n<p>1.栅栏</p>\r\n\r\n<ul>\r\n	<li>弹性布局：我理解的所谓弹性布局就是一种可以将一个任何大小的界面分为几份的一个东西。它将你要操作的位置一分为12份，你可以将你想要展示的东西放在你想要的位置，对于我这种新手来说，这种布局简直是好的不能在好了。</li>\r\n</ul>\r\n\r\n<p>2.样式</p>\r\n\r\n<ul>\r\n	<li>卡片的运用</li>\r\n	<li>未完待续。。。</li>\r\n</ul>\r\n<p>如果不做前端的话，就不要在前端上面花时间，前端挺浪费时间的，而且回报太小了；感觉前端各种框框架架的调来调去的太花费时间了，而且如果是我这样的零基础的话，花了时间也不能做出好看的界面，还不如多花点时间在算法和数据结构上。这样一来可以锻炼自己的思维，二来快速提升自己的代码能力。</p>\r\n<p>经过一段时间的数据结构的学习，我才知道这门技能的重要性，而且难度也不是一般的高，真正的易学难精。想学数据结构，数据结构确实就几个，数组、队列、栈、散列表、图（含树）、链表。就概念来说都挺容易懂得，但是真正去实际运用的时候觉得这种结构的设计真是巧妙啊。不愧是经典的结构。为什么说去学算法和数据结构能锻炼思维和代码能力呢：</p>\r\n<ul>\r\n	<li>锻炼思维：首先设计算法来解决一个实际问题很锻炼一个人的逻辑性，遇到递归这种，感觉头的想炸了，你要想方设法的去求解，去找出最佳的方法。怎么才能降低时间复杂度和空间复杂度。用什么数据结构才能最好的解决这个问题。这些都是我们要思考的问题。所以说学习算法和数据结构锻炼人的思维。</li>\r\n	<li>提升代码能力：最近去LeeCode上刷题的时候，自己已经想到了解决的方法，也知道用什么数据结构，但是在写代码的时候，总感觉无从下手，感觉很多东西不知道怎么表达。所以我们在解决一个问题的时候，还能同时提升我们的代码能力。</li>\r\n</ul>\r\n<p>因此，我决定以后放弃对前端东西的优化，转而学习更多的算法，接收更多思想，毕竟我不是一个有艺术细胞的人。设计不出令人赞叹的界面。也写不出炫酷的特效。因此，只能老老实实学习点实用的东西。《吐槽：每次写完笔记都不忍心回头去看，文笔实在是太垃圾了》</p>\r\n','2019-12-10 09:01:59.691275','2020-03-30 12:10:41.875308',1,167,2,2,''),(8,'Docker入门教程','<p>2013年发布至今，Docker一直广受瞩目，被认为可能会改变软件行业。</p>\r\n\r\n<p>但是，许多人并不清楚 Docker 到底是什么，要解决什么问题，好处又在哪里？本文就来详细解释，帮助大家理解它，还带有简单易懂的实例，教你如何将它用于日常开发。</p>\r\n\r\n<p><img alt=\"\" src=\"http://www.ruanyifeng.com/blogimg/asset/2018/bg2018020901.png\" title=\"\" / style=\"width:100%;\"></p>\r\n\r\n<p>一、环境配置的难题</p>\r\n\r\n<p>软件开发最大的麻烦事之一，就是环境配置。用户计算机的环境都不相同，你怎么知道自家的软件，能在那些机器跑起来？</p>\r\n\r\n<p>用户必须保证两件事：操作系统的设置，各种库和组件的安装。只有它们都正确，软件才能运行。举例来说，安装一个 Python 应用，计算机必须有 Python 引擎，还必须有各种依赖，可能还要配置环境变量。</p>\r\n\r\n<p>如果某些老旧的模块与当前环境不兼容，那就麻烦了。开发者常常会说：&quot;它在我的机器可以跑了&quot;（It works on my machine），言下之意就是，其他机器很可能跑不了。</p>\r\n\r\n<p>环境配置如此麻烦，换一台机器，就要重来一次，旷日费时。很多人想到，能不能从根本上解决问题，软件可以带环境安装？也就是说，安装的时候，把原始环境一模一样地复制过来。</p>\r\n\r\n<p>二、虚拟机</p>\r\n\r\n<p>虚拟机（virtual machine）就是带环境安装的一种解决方案。它可以在一种操作系统里面运行另一种操作系统，比如在 Windows 系统里面运行 Linux 系统。应用程序对此毫无感知，因为虚拟机看上去跟真实系统一模一样，而对于底层系统来说，虚拟机就是一个普通文件，不需要了就删掉，对其他部分毫无影响。</p>\r\n\r\n<p>虽然用户可以通过虚拟机还原软件的原始环境。但是，这个方案有几个缺点。</p>\r\n\r\n<p><strong>（1）资源占用多</strong></p>\r\n\r\n<p>虚拟机会独占一部分内存和硬盘空间。它运行的时候，其他程序就不能使用这些资源了。哪怕虚拟机里面的应用程序，真正使用的内存只有 1MB，虚拟机依然需要几百 MB 的内存才能运行。</p>\r\n\r\n<p><strong>（2）冗余步骤多</strong></p>\r\n\r\n<p>虚拟机是完整的操作系统，一些系统级别的操作步骤，往往无法跳过，比如用户登录。</p>\r\n\r\n<p><strong>（3）启动慢</strong></p>\r\n\r\n<p>启动操作系统需要多久，启动虚拟机就需要多久。可能要等几分钟，应用程序才能真正运行。</p>\r\n\r\n<p>三、Linux 容器</p>\r\n\r\n<p>由于虚拟机存在这些缺点，Linux 发展出了另一种虚拟化技术：Linux 容器（Linux Containers，缩写为 LXC）。</p>\r\n\r\n<p><strong>Linux 容器不是模拟一个完整的操作系统，而是对进程进行隔离。</strong>或者说，在正常进程的外面套了一个保护层。对于容器里面的进程来说，它接触到的各种资源都是虚拟的，从而实现与底层系统的隔离。</p>\r\n\r\n<p>由于容器是进程级别的，相比虚拟机有很多优势。</p>\r\n\r\n<p><strong>（1）启动快</strong></p>\r\n\r\n<p>容器里面的应用，直接就是底层系统的一个进程，而不是虚拟机内部的进程。所以，启动容器相当于启动本机的一个进程，而不是启动一个操作系统，速度就快很多。</p>\r\n\r\n<p><strong>（2）资源占用少</strong></p>\r\n\r\n<p>容器只占用需要的资源，不占用那些没有用到的资源；虚拟机由于是完整的操作系统，不可避免要占用所有资源。另外，多个容器可以共享资源，虚拟机都是独享资源。</p>\r\n\r\n<p><strong>（3）体积小</strong></p>\r\n\r\n<p>容器只要包含用到的组件即可，而虚拟机是整个操作系统的打包，所以容器文件比虚拟机文件要小很多。</p>\r\n\r\n<p>总之，容器有点像轻量级的虚拟机，能够提供虚拟化的环境，但是成本开销小得多。</p>\r\n\r\n<p>四、Docker 是什么？</p>\r\n\r\n<p><strong>Docker 属于 Linux 容器的一种封装，提供简单易用的容器使用接口。</strong>它是目前最流行的 Linux 容器解决方案。</p>\r\n\r\n<p>Docker 将应用程序与该程序的依赖，打包在一个文件里面。运行这个文件，就会生成一个虚拟容器。程序在这个虚拟容器里运行，就好像在真实的物理机上运行一样。有了 Docker，就不用担心环境问题。</p>\r\n\r\n<p>总体来说，Docker 的接口相当简单，用户可以方便地创建和使用容器，把自己的应用放入容器。容器还可以进行版本管理、复制、分享、修改，就像管理普通的代码一样。</p>\r\n\r\n<p>五、Docker 的用途</p>\r\n\r\n<p>Docker 的主要用途，目前有三大类。</p>\r\n\r\n<p><strong>（1）提供一次性的环境。</strong>比如，本地测试他人的软件、持续集成的时候提供单元测试和构建的环境。</p>\r\n\r\n<p><strong>（2）提供弹性的云服务。</strong>因为 Docker 容器可以随开随关，很适合动态扩容和缩容。</p>\r\n\r\n<p><strong>（3）组建微服务架构。</strong>通过多个容器，一台机器可以跑多个服务，因此在本机就可以模拟出微服务架构。</p>','2019-12-11 07:28:57.247986','2019-12-12 06:31:20.916789',1,44,1,0,''),(9,'Linux命令行的艺术','<p>日常使用</p>\r\n\r\n<ul>\r\n	<li>\r\n	<p>在 Bash 中，可以通过按&nbsp;<strong>Tab</strong>&nbsp;键实现自动补全参数，使用&nbsp;<strong>ctrl-r</strong>&nbsp;搜索命令行历史记录（按下按键之后，输入关键字便可以搜索，重复按下&nbsp;<strong>ctrl-r</strong>&nbsp;会向后查找匹配项，按下&nbsp;<strong>Enter</strong>&nbsp;键会执行当前匹配的命令，而按下右方向键会将匹配项放入当前行中，不会直接执行，以便做出修改）。</p>\r\n	</li>\r\n	<li>\r\n	<p>在 Bash 中，可以按下&nbsp;<strong>ctrl-w</strong>&nbsp;删除你键入的最后一个单词，<strong>ctrl-u</strong>&nbsp;可以删除行内光标所在位置之前的内容，<strong>alt-b</strong>&nbsp;和&nbsp;<strong>alt-f</strong>&nbsp;可以以单词为单位移动光标，<strong>ctrl-a</strong>&nbsp;可以将光标移至行首，<strong>ctrl-e</strong>&nbsp;可以将光标移至行尾，<strong>ctrl-k</strong>&nbsp;可以删除光标至行尾的所有内容，<strong>ctrl-l</strong>&nbsp;可以清屏。键入&nbsp;<code>man readline</code>&nbsp;可以查看 Bash 中的默认快捷键。内容有很多，例如&nbsp;<strong>alt-.</strong>&nbsp;循环地移向前一个参数，而&nbsp;<strong>alt-</strong>* 可以展开通配符。</p>\r\n	</li>\r\n	<li>\r\n	<p>你喜欢的话，可以执行&nbsp;<code>set -o vi</code>&nbsp;来使用 vi 风格的快捷键，而执行&nbsp;<code>set -o emacs</code>&nbsp;可以把它改回来。</p>\r\n	</li>\r\n	<li>\r\n	<p>为了便于编辑长命令，在设置你的默认编辑器后（例如&nbsp;<code>export EDITOR=vim</code>），<strong>ctrl-x</strong>&nbsp;<strong>ctrl-e</strong>&nbsp;会打开一个编辑器来编辑当前输入的命令。在 vi 风格下快捷键则是&nbsp;<strong>escape-v</strong>。</p>\r\n	</li>\r\n	<li>\r\n	<p>键入&nbsp;<code>history</code>&nbsp;查看命令行历史记录，再用&nbsp;<code>!n</code>（<code>n</code>&nbsp;是命令编号）就可以再次执行。其中有许多缩写，最有用的大概就是&nbsp;<code>!$</code>， 它用于指代上次键入的参数，而&nbsp;<code>!!</code>&nbsp;可以指代上次键入的命令了（参考 man 页面中的&ldquo;HISTORY EXPANSION&rdquo;）。不过这些功能，你也可以通过快捷键&nbsp;<strong>ctrl-r</strong>&nbsp;和&nbsp;<strong>alt-.</strong>&nbsp;来实现。</p>\r\n	</li>\r\n	<li>\r\n	<p><code>cd</code>&nbsp;命令可以切换工作路径，输入&nbsp;<code>cd ~</code>&nbsp;可以进入 home 目录。要访问你的 home 目录中的文件，可以使用前缀&nbsp;<code>~</code>（例如&nbsp;<code>~/.bashrc</code>）。在&nbsp;<code>sh</code>&nbsp;脚本里则用环境变量&nbsp;<code>$HOME</code>&nbsp;指代 home 目录的路径。</p>\r\n	</li>\r\n	<li>\r\n	<p>回到前一个工作路径：<code>cd -</code>。</p>\r\n	</li>\r\n	<li>\r\n	<p>如果你输入命令的时候中途改了主意，按下&nbsp;<strong>alt-#</strong>&nbsp;在行首添加&nbsp;<code>#</code>&nbsp;把它当做注释再按下回车执行（或者依次按下&nbsp;<strong>ctrl-a</strong>，&nbsp;<strong>#</strong>，&nbsp;<strong>enter</strong>）。这样做的话，之后借助命令行历史记录，你可以很方便恢复你刚才输入到一半的命令。</p>\r\n	</li>\r\n	<li>\r\n	<p>使用&nbsp;<code>xargs</code>&nbsp;（ 或&nbsp;<code>parallel</code>）。他们非常给力。注意到你可以控制每行参数个数（<code>-L</code>）和最大并行数（<code>-P</code>）。如果你不确定它们是否会按你想的那样工作，先使用&nbsp;<code>xargs echo</code>&nbsp;查看一下。此外，使用&nbsp;<code>-I{}</code>&nbsp;会很方便。例如：</p>\r\n	</li>\r\n</ul>\r\n\r\n<pre>\r\n      find . -name &#39;*.py&#39; | xargs grep some_function\r\n      cat hosts | xargs -I{} ssh root@{} hostname</pre>\r\n\r\n<ul>\r\n	<li>\r\n	<p><code>pstree -p</code>&nbsp;以一种优雅的方式展示进程树。</p>\r\n	</li>\r\n	<li>\r\n	<p>使用&nbsp;<code>pgrep</code>&nbsp;和&nbsp;<code>pkill</code>&nbsp;根据名字查找进程或发送信号（<code>-f</code>&nbsp;参数通常有用）。</p>\r\n	</li>\r\n	<li>\r\n	<p>了解你可以发往进程的信号的种类。比如，使用&nbsp;<code>kill -STOP [pid]</code>&nbsp;停止一个进程。使用&nbsp;<code>man 7 signal</code>&nbsp;查看详细列表。</p>\r\n	</li>\r\n	<li>\r\n	<p>使用&nbsp;<code>nohup</code>&nbsp;或&nbsp;<code>disown</code>&nbsp;使一个后台进程持续运行。</p>\r\n	</li>\r\n	<li>\r\n	<p>使用&nbsp;<code>netstat -lntp</code>&nbsp;或&nbsp;<code>ss -plat</code>&nbsp;检查哪些进程在监听端口（默认是检查 TCP 端口; 添加参数&nbsp;<code>-u</code>&nbsp;则检查 UDP 端口）或者&nbsp;<code>lsof -iTCP -sTCP:LISTEN -P -n</code>&nbsp;(这也可以在 OS X 上运行)。</p>\r\n	</li>\r\n	<li>\r\n	<p><code>lsof</code>&nbsp;来查看开启的套接字和文件。</p>\r\n	</li>\r\n	<li>\r\n	<p>使用&nbsp;<code>uptime</code>&nbsp;或&nbsp;<code>w</code>&nbsp;来查看系统已经运行多长时间。</p>\r\n	</li>\r\n	<li>\r\n	<p>使用&nbsp;<code>alias</code>&nbsp;来创建常用命令的快捷形式。例如：<code>alias ll=&#39;ls -latr&#39;</code>&nbsp;创建了一个新的命令别名&nbsp;<code>ll</code>。</p>\r\n	</li>\r\n	<li>\r\n	<p>可以把别名、shell 选项和常用函数保存在&nbsp;<code>~/.bashrc</code>，具体看下这篇<a href=\"http://superuser.com/a/183980/7106\" rel=\"nofollow\">文章</a>。这样做的话你就可以在所有 shell 会话中使用你的设定。</p>\r\n	</li>\r\n	<li>\r\n	<p>把环境变量的设定以及登陆时要执行的命令保存在&nbsp;<code>~/.bash_profile</code>。而对于从图形界面启动的 shell 和&nbsp;<code>cron</code>&nbsp;启动的 shell，则需要单独配置文件。</p>\r\n	</li>\r\n	<li>\r\n	<p>要想在几台电脑中同步你的配置文件（例如&nbsp;<code>.bashrc</code>&nbsp;和&nbsp;<code>.bash_profile</code>），可以借助 Git。</p>\r\n	</li>\r\n	<li>\r\n	<p>当变量和文件名中包含空格的时候要格外小心。Bash 变量要用引号括起来，比如&nbsp;<code>&quot;$FOO&quot;</code>。尽量使用&nbsp;<code>-0</code>&nbsp;或&nbsp;<code>-print0</code>&nbsp;选项以便用 NULL 来分隔文件名，例如&nbsp;<code>locate -0 pattern | xargs -0 ls -al</code>&nbsp;或&nbsp;<code>find / -print0 -type d | xargs -0 ls -al</code>。如果 for 循环中循环访问的文件名含有空字符（空格、tab 等字符），只需用&nbsp;<code>IFS=$&#39;\\n&#39;</code>&nbsp;把内部字段分隔符设为换行符。</p>\r\n	</li>\r\n	<li>\r\n	<p>在 Bash 脚本中，使用&nbsp;<code>set -x</code>&nbsp;去调试输出（或者使用它的变体&nbsp;<code>set -v</code>，它会记录原始输入，包括多余的参数和注释）。尽可能地使用严格模式：使用&nbsp;<code>set -e</code>&nbsp;令脚本在发生错误时退出而不是继续运行；使用&nbsp;<code>set -u</code>&nbsp;来检查是否使用了未赋值的变量；试试&nbsp;<code>set -o pipefail</code>，它可以监测管道中的错误。当牵扯到很多脚本时，使用&nbsp;<code>trap</code>&nbsp;来检测 ERR 和 EXIT。一个好的习惯是在脚本文件开头这样写，这会使它能够检测一些错误，并在错误发生时中断程序并输出信息：</p>\r\n	</li>\r\n</ul>\r\n\r\n<pre>\r\n      set -euo pipefail\r\n      trap &quot;echo &#39;error: Script failed: see failed command above&#39;&quot; ERR</pre>\r\n\r\n<ul>\r\n	<li>在 Bash 脚本中，子 shell（使用括号&nbsp;<code>(...)</code>）是一种组织参数的便捷方式。一个常见的例子是临时地移动工作路径，代码如下：</li>\r\n</ul>\r\n\r\n<pre>\r\n      # do something in current dir\r\n      (cd /some/other/dir &amp;&amp; other-command)\r\n      # continue in original dir</pre>\r\n\r\n<ul>\r\n	<li>\r\n	<p>在 Bash 中，变量有许多的扩展方式。<code>${name:?error message}</code>&nbsp;用于检查变量是否存在。此外，当 Bash 脚本只需要一个参数时，可以使用这样的代码&nbsp;<code>input_file=${1:?usage: $0 input_file}</code>。在变量为空时使用默认值：<code>${name:-default}</code>。如果你要在之前的例子中再加一个（可选的）参数，可以使用类似这样的代码&nbsp;<code>output_file=${2:-logfile}</code>，如果省略了 $2，它的值就为空，于是&nbsp;<code>output_file</code>&nbsp;就会被设为&nbsp;<code>logfile</code>。数学表达式：<code>i=$(( (i + 1) % 5 ))</code>。序列：<code>{1..10}</code>。截断字符串：<code>${var%suffix}</code>&nbsp;和&nbsp;<code>${var#prefix}</code>。例如，假设&nbsp;<code>var=foo.pdf</code>，那么&nbsp;<code>echo ${var%.pdf}.txt</code>&nbsp;将输出&nbsp;<code>foo.txt</code>。</p>\r\n	</li>\r\n	<li>\r\n	<p>使用括号扩展（<code>{</code>...<code>}</code>）来减少输入相似文本，并自动化文本组合。这在某些情况下会很有用，例如&nbsp;<code>mv foo.{txt,pdf} some-dir</code>（同时移动两个文件），<code>cp somefile{,.bak}</code>（会被扩展成&nbsp;<code>cp somefile somefile.bak</code>）或者&nbsp;<code>mkdir -p test-{a,b,c}/subtest-{1,2,3}</code>（会被扩展成所有可能的组合，并创建一个目录树）。</p>\r\n	</li>\r\n</ul>','2019-12-12 02:34:17.539567','2019-12-12 02:34:17.543097',1,34,1,0,''),(10,'简单实用的Xargs命令','<p>xargs是一个十分好用的linux命令，历经一天的学习，现在是时候总结一下学习的收获了。</p>\r\n\r\n<p>首先要明白何时需要用到这个命令。当我们需要对我们的标准输出做一些操作的时候，它就派上用场了；常用的场景，当我们使用管道符的时候，可以在管道符后面使用xargs，将前面的输出，作为后面的标准输入。例如：</p>\r\n\r\n<pre>\r\n<code class=\"language-vim\">echo \"hello world\" | xargs echo</code></pre>\r\n\r\n<p>当然也不仅限于在管道符后面使用，它也可以直接使用。</p>\r\n\r\n<pre>\r\n<code class=\"language-vim\">xargs  #相当于xargs echo\r\ninput string #输入内容,然后Ctrl+d结束</code></pre>\r\n\r\n<p>xargs用法也也如同其他linux的命令一样，后面先接参数，再接其他命令（有但不限于rm mkdir ls echo grep等常用命令）。形式如下：</p>\r\n\r\n<pre>\r\n<code class=\"language-vim\">xargs [-options] [command]</code></pre>\r\n\r\n<p>&nbsp;刚刚也说了，xargs后面接参数和命令，命令是常用命令，参数又有哪些呢！又到最难受的参数讲解环节了。</p>\r\n\r\n<p><b>1. -d 参数</b></p>\r\n\r\n<ul>\r\n	<li>-d参数主要是指定分隔符的作用，如果不指定，默认以空格和换行作为分隔符。如果使用-d参数指定的话，分隔符则为指定符号。例如：</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-vim\">echo \"file1 file2 file3\" | xargs touch #默认以空格作为分隔符，创建3个空文件\r\n#使用-d参数\r\necho \"file1-file2-file3\" | xargs -d \"-\" echo\r\noutput: file1 file2 file3</code></pre>\r\n\r\n<ul>\r\n	<li>指定&ldquo;-&rdquo;作为分隔符后，输出将分隔符为&ldquo;-&rdquo;的内容分隔开了。</li>\r\n</ul>\r\n\r\n<p><b>2. -0 参数（零）</b></p>\r\n\r\n<ul>\r\n	<li>-d参数处理文件的时候，如果文件有空格什么的，那么除了用分隔符分开的文件外，空格也会被当做参数处理，文件后面后多个问号。因此处理文件的时候，我们还是使用 -0，但是-0 还需要配合find -print0使用。使用方法如下：</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-vim\">find ./ -name \"file*\" -print0 | xargs -0 rm\r\n</code></pre>\r\n\r\n<ul>\r\n	<li>-print0 默认以null分隔，而-0也是默认以null为分隔符，分隔参数。因此就算文件中带有空格，同样能处理。</li>\r\n</ul>\r\n<br>\r\n<p><b>3.&nbsp; -L参数</b></p>\r\n\r\n<ul>\r\n	<li>如果参数包含多行的情况下，我们可以使用-L来指定多少行作为一个参数。</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-vim\">$ xargs find -name\r\n\"*.py\"\r\n\"*.yml\"\r\nfind: paths must precede expression: *.yml #会报错\r\n\r\n#使用-L后完美运行\r\n$ xargs -L 1 find -name\r\n\"*.py\"\r\n./Notebook.py\r\n./test.py\r\n\"*.yml\"./production.yml\r\n</code></pre>\r\n<br>\r\n<p><b>4. -n 参数</b></p>\r\n\r\n<ul>\r\n	<li>-L参数可以控制参数行数，但是如果想要一行输入多个参数，怎么办呢！-n可以帮到我们。使用如下：</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-vim\">#每行两个参数\r\n$ echo {0..9} | xargs -n 2 echo\r\n0 1\r\n2 3\r\n4 5\r\n6 7\r\n8 9</code></pre>\r\n<br>\r\n<p><b>5. - I 参数</b></p>\r\n\r\n<ul>\r\n	<li>-I 参数可以让我们将参数传给多个命令运行。</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-vim\">$ touch file1 file2 file3 #创建几个文件来实验一下\r\n$ find ./ -name \"file*\" | xargs -I file sh -c \"echo file; rm file\"\r\n./file1\r\n./file3\r\n./file2\r\n#再ls查看文件已经被删除了</code></pre>\r\n<br>\r\n<p><b>6.--max-procs 参数</b></p>\r\n\r\n<ul>\r\n	<li><code>xargs</code>默认只用一个进程执行命令。如果命令要执行多次，必须等上一次执行完，才能执行下一次。<code>--max-procs</code>参数指定同时用多少个进程并行执行命令。<code>--max-procs 2</code>表示同时最多使用两个进程，<code>--max-procs 0</code>表示不限制进程数。</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-vim\">$ docker ps -q | xargs -n 1 --max-procs 0 docker kill</code></pre>\r\n\r\n<ul>\r\n	<li>&nbsp;这样命令运行速度要快很多。</li>\r\n</ul>','2019-12-12 04:02:07.989051','2019-12-18 02:37:49.707690',1,60,1,1,''),(11,'MySQL数据库自动备份','<p>数据是网站运行不可或缺的一个部分，为了防止数据丢失，合理的数据也应是我们必备的素养之一。这篇文章将记录如何在阿里云上实现自动备份MySQL数据库。</p>\r\n\r\n<p><img alt=\"\" src=\"http://static.zybuluo.com/feixuelove1009/nbc2jwhltc1vxvloelf713i9/29.png\" style=\"width:100%\" /></p>\r\n\r\n<p><strong>1. MySQL数据备份方法Mysqldump</strong></p>\r\n\r\n<pre>\r\n<code class=\"language-vim\"># 备份单个的数据库，如备份DatabaseName这个数据库\r\nmysqldump -u[root] -p[Password] DatabaseName &gt; /[backup path]/DatabaseName_`date +%m%d%Y%M`.sql\r\n\r\n# 备份所有数据库，-A参数\r\nmysqldump -uroot -p[Password] -A &gt; /[backup path]/mysql_bak_`date +%m%d%Y%M`.sql\r\n\r\n# 备份远程主机的数据库，-h指定IP地址，-P(大写P)指定端口\r\nmysqldump -uroot -p[Password] -h[IP] -P3306 DatabaseName &gt; /[backup path]/DatabaseName.sql\r\n\r\n# 使用-d参数，备份表结构\r\nmysqldump -uroot -p[Password] -d DatabaseName &gt; /[backup path]/DatabaseName.sql\r\n\r\n# 使用-t参数，只备份数据，不备份结构\r\nmysqldump -uroot -p[Password] -t DatabaseName &gt; /[backup path]/DatabaseName.sql \r\n\r\n# 同时备份多个库\r\nmysqldump -uroot -p[Password] -B DB1 DB2 DB3 &gt; /[backup path]/DB123.sql\r\n\r\n# 备份指定的表，如备份DatabaseName库里面的post表\r\nmysqldump -uroot -p[Password] DatabaseName post &gt; /[backup path]/DatabaseName_post.sql\r\n\r\n# 同时备份多个表\r\nmysqldump -uroot -p[Password] 库1 表1 表2 表3... &gt; [DatabaseTable].sql\r\n\r\n# 使用备份文件恢复数据\r\nmysqldump -uroot -p[Password] DatabaseName &lt; [backuped database].sql\r\n</code></pre>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2. 顺便一提date时间格式的匹配</strong></p>\r\n\r\n<ul>\r\n	<li>因为备份的时候最好将时间体现在文件名上，方便我们以后查找，因此我觉得时间格式还是尤为重要的，我们大概要知道怎么匹配出我们需要的时间格式。</li>\r\n	<li>比如说，我需要备份的时间和时间点，我就可以用`date +%m%d%Y%M` 就会输出12120929，这样作为文件名较为美观、简洁。如果使用2019-12-12 09:30 的话，虽然容易理解，但是太长了。</li>\r\n	<li>现在弄一份时间格式，方便以后查找使用。</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-vim\">%H 小时，24小时制（00~23）\r\n%I 小时，12小时制（01~12）\r\n%k 小时，24小时制（0~23）\r\n%l 小时，12小时制（1~12）\r\n%M 分钟（00~59）\r\n%p 显示出AM或PM\r\n%r 显示时间，12小时制（hh:mm:ss %p）\r\n%s 从1970年1月1日00:00:00到目前经历的秒数\r\n%S 显示秒（00~59）\r\n%T 显示时间，24小时制（hh:mm:ss）\r\n%X 显示时间的格式（%H:%M:%S）\r\n%Z 显示时区，日期域（CST）\r\n%a 星期的简称（Sun~Sat）\r\n%A 星期的全称（Sunday~Saturday）\r\n%h,%b 月的简称（Jan~Dec）\r\n%B 月的全称（January~December）\r\n%c 日期和时间（Tue Nov 20 14:12:58 2012）\r\n%d 一个月的第几天（01~31）\r\n%x,%D 日期（mm/dd/yy）\r\n%j 一年的第几天（001~366）\r\n%m 月份（01~12）\r\n%w 一个星期的第几天（0代表星期天）\r\n%W 一年的第几个星期（00~53，星期一为第一天）\r\n%y 年的最后两个数字（1999则是99）</code></pre>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>3. 备份脚本</strong></p>\r\n\r\n<ul>\r\n	<li>将我们要做的工作写成一个脚本，这样我们就不用每次都输入很多命令才能实现备份了，一劳永逸。</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-vim\">#!/bin/bash\r\n#set mysql info \r\nhostname=\"localhost\"\r\nuser=\"root\"\r\npassword=\"123456\"\r\n\r\n#set database info\r\ndatabase=\"blog_data\"\r\nbakpath=\"/home/limouyin/data/backup\"\r\ndate=`date +%m%d%H%M`\r\n\r\n#backup\r\nmysqldump -h$hostname -u$user -p$password $database &gt; $bakpath/$database\\_$date.sql\r\n\r\n#compression\r\ncd $bakpath\r\ngzip *_$date.sql\r\nfind ./ -name \"*.gz\" -mtime +15 | xargs rm #Delete previous backups\r\n</code></pre>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>4. 创建定时任务Crontab</strong></p>\r\n\r\n<ul>\r\n	<li>首先讲解一下crontab的命令用法，命令格式为：</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-vim\">minute   hour   day   month   week   command  顺序：分 时 日 月 周</code></pre>\r\n\r\n<p>其中：</p>\r\n\r\n<ul>\r\n	<li>minute：&nbsp;表示分钟，可以是从0到59之间的任何整数。</li>\r\n	<li>hour：表示小时，可以是从0到23之间的任何整数。</li>\r\n	<li>day：表示日期，可以是从1到31之间的任何整数。</li>\r\n	<li>month：表示月份，可以是从1到12之间的任何整数。</li>\r\n	<li>week：表示星期几，可以是从0到7之间的任何整数，这里的0或7代表星期日。</li>\r\n	<li>command：要执行的命令，可以是系统命令，也可以是自己编写的脚本文件。</li>\r\n</ul>\r\n\r\n<p>在以上各个字段中，还可以使用以下特殊字符：</p>\r\n\r\n<ul>\r\n	<li>星号（*）：代表所有可能的值，例如month字段如果是星号，则表示在满足其它字段的制约条件后每月都执行该命令操作。</li>\r\n	<li>逗号（,）：可以用逗号隔开的值指定一个列表范围，例如，&ldquo;1,2,5,7,8,9&rdquo;</li>\r\n	<li>中杠（-）：可以用整数之间的中杠表示一个整数范围，例如&ldquo;2-6&rdquo;表示&ldquo;2,3,4,5,6&rdquo;</li>\r\n	<li>正斜线（/）：可以用正斜线指定时间的间隔频率，例如&ldquo;0-23/2&rdquo;表示每两小时执行一次。同时正斜线可以和星号一起使用，例如*/10，如果用在minute字段，表示每十分钟执行一次。</li>\r\n</ul>\r\n\r\n<p>看个例子：</p>\r\n\r\n<pre>\r\n<code class=\"language-vim\">#每分钟执行一次command \r\n* * * * * command\r\n#每小时35分执行一次\r\n35 * * * * command\r\n#每天12点35分执行一次\r\n35 12 * * * command\r\n#每周一12点35分执行一次\r\n35 12 * * 1 command</code></pre>\r\n\r\n<blockquote>\r\n<p>以此类推，我们应该能明白他的执行原理。</p>\r\n</blockquote>\r\n\r\n<ul>\r\n	<li>下面正式使用crontab执行我们备份的定时任务，先在命令行执行，<strong>crontab -e，</strong>打开一个编辑器，在里面写入我们的定时任务。</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-vim\">0 12 * * * /bin/bash /home/limouyin/data/mysql_backup.sh &gt;/tmp/mysql_backup.log 2&gt;/tmp/mysql_backup.log</code></pre>\r\n\r\n<ul>\r\n	<li>这条命令让我们的脚本每天12点执行一次，并将只写的日志写入mysql_backup.log中。最后我们可以用<strong>crontab -l</strong>&nbsp;查看我们当前正在运行的定时任务。</li>\r\n	<li><em><strong>小提示：如果我们的命令需要root权限，需要用sudo才能执行的话，我们可以使用root用户来写定时任务。</strong></em></li>\r\n</ul>','2019-12-13 02:01:08.808419','2019-12-13 06:35:48.956763',1,47,1,0,''),(12,'排序算法笔记（一）','<p>算法是解题方案的准确而完整的描述，是一系列解决问题的清晰指令。同一问题可用不同算法解决，而一个算法的质量优劣将影响到算法乃至程序的效率。算法分析的目的在于选择合适算法和改进算法。一个算法的评价主要从时间复杂度和空间复杂度来考虑。所以一个好的算法，能否大大提高解决问题的效率，因此算法对于计算机来说尤为重要。</p>\r\n\r\n<p>今天主要记录快速排序和选择排序。</p>\r\n\r\n<p><strong>一、选择排序（Selection Sort）</strong></p>\r\n\r\n<p>选择排序(Selection-sort)是一种简单直观的排序算法。它的工作原理：首先在未排序序列中找到最小（大）元素，将其弹出存放在排序序列的起始位置，然后，再从剩余未排序元素中继续寻找最小（大）元素，然后放到已排序序列的末尾。以此类推，直到所有元素均排序完毕。 基本步骤：</p>\r\n\r\n<ul>\r\n	<li>从n个元素序列中找到最值</li>\r\n	<li>将找出的值从序列中弹出并添加入新的序列中</li>\r\n	<li>在从剩余n-1个元素的找出最值，如此循环，直至找到最后一个元素</li>\r\n</ul>\r\n\r\n<p>每次查找n个元素（其实没有那么多次，平均应该查找n/2次，但是大O表示法会省略一些常数），查找n次，因此<strong>选择排序的时间复杂度为O(n^2)</strong></p>\r\n\r\n<p>Python代码实现：</p>\r\n\r\n<p>1. 首先定义一个从序列中找到最值的函数</p>\r\n\r\n<pre>\r\n<code class=\"language-python\">def findminvalue(arr):\r\n    minvalue = arr[0]\r\n    minvalue_index = 0\r\n    for i in range(1, len(arr)):\r\n        if arr[i] &lt; minvalue:\r\n            minvalue = arr[i]\r\n            minvalue_index = i\r\n    return minvalue_index\r\n</code></pre>\r\n\r\n<p>2. 将挑选出来的值从原序列中弹出并加入新序列</p>\r\n\r\n<pre>\r\n<code class=\"language-python\">def sesort(arr):\r\n    newarr = []\r\n    for i in range(len(arr)):\r\n        minvalue = findminvalue(arr)\r\n        newarr.append(arr.pop(minvalue))\r\n    return newarr\r\n\r\nsesort([6, 3, 4, 5, 9, 10, 20])\r\n[out]: [3, 4, 5, 6, 9, 10, 20]</code></pre>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>二、快速排序（Quick Sort）</strong></p>\r\n\r\n<p>快速排序使用分而治之（D&amp;C）的策略来把一个序列（list）分为较小和较大的2个子序列，然后递归地排序两个子序列。</p>\r\n\r\n<p>步骤为：</p>\r\n\r\n<ul>\r\n	<li>挑选基准值：从数列中挑出一个元素，称为&quot;基准&quot;（pivot）。</li>\r\n	<li>将序列以基准值为标准，分为一个大于基准值的子序列，和一个小于基准值的子序列。</li>\r\n	<li>将分好后的子序列在调用函数吗，在进行细分，一直递归进行，直至满足基线条件为止。</li>\r\n</ul>\r\n\r\n<p>递归到最底部的判断条件是数列的大小是零或一，此时该数列显然已经有序。</p>\r\n\r\n<p>选取基准值有数种具体方法，此选取方法对排序的时间性能有决定性影响。</p>\r\n\r\n<p><strong>快速排序的平均情况的时间复杂度为O(nlogn)（默认以2为底），最糟糕情况下的时间复杂度为O(n^2)</strong></p>\r\n\r\n<p>Python代码实现：</p>\r\n\r\n<p>基准值的选择十分重要，选择合适的基准值，可以决定算法的效率。这里我们将第一个元素作为基准值。</p>\r\n\r\n<pre>\r\n<code class=\"language-python\">def qsort(arr):\r\n    if len(arr) &lt; 2: #基线条件\r\n        return arr\r\n    else: #递归条件\r\n        pivot = arr[0]\r\n        less = [i for i in arr[1:] if i &lt;= pivot]\r\n        greater = [i for i in arr[1:] if i &gt; pivot]\r\n        return qsort(less) + [pivot] + qsort(greater)\r\n\r\nqsort([4, 6, 8, 3, 2, 5])\r\n[out]: [2, 3, 4, 5, 6, 8]</code></pre>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>三、用类改写两个方法</strong></p>\r\n\r\n<pre>\r\n<code class=\"language-python\">class Sort():\r\n    def __init__(self, arr):\r\n        self.arr = arr\r\n        \r\n    def qsort(self):\r\n        if len(self.arr) &lt; 2:\r\n            return self.arr\r\n        else:\r\n            pivot = self.arr[0]\r\n            less = [i for i in self.arr[1:] if i &lt;= pivot]\r\n            greater = [i for i in self.arr[1:] if i &gt; pivot]\r\n            return qsort(less) + [pivot] + qsort(greater)\r\n        \r\n    def findminvalue(self):\r\n        minvalue = self.arr[0]\r\n        minvalue_index = 0\r\n        for i in range(1, len(self.arr)):\r\n            if self.arr[i] &lt; minvalue:\r\n                minvalue = self.arr[i]\r\n                minvalue_index = i\r\n        return minvalue_index\r\n    \r\n    def sesort(self):\r\n        newarr = []\r\n        for i in range(len(self.arr)):\r\n            minvalue = findminvalue(self.arr)\r\n            newarr.append(self.arr.pop(minvalue))\r\n        return newarr</code></pre>\r\n\r\n<p><strong><em>如有错误，请批评指正！</em></strong></p>','2019-12-17 05:08:47.162374','2019-12-17 05:11:13.717533',1,64,1,0,''),(13,'Python多进程与多线程','<p>多进程多线程一直是计算机界的热门话题，似乎已成为每一个码农入门的必修课之一。那么，我们几天就来捋一捋Python的多线程和多进程。在这之前，我们应该先知道什么是进程，什么是线程，他们之间存在什么样的关系。</p>\r\n\r\n<p><strong>1. 什么是多进程、多线程</strong></p>\r\n\r\n<p>我们都知道CPU是计算机的核心，用于承担所有的计算任务，如果是单核CPU，那么它一次只能处理一个任务。进程代表CPU所能处理的单个任务。任一时刻，CPU总是运行一个进程，其他进程处于非运行状态。多核CPU同时可使用多个进程，但平时只用一个。一个cpu包括多个进程，一个进程又包括多个线程。每个进程在执行过程中拥有独立的内存单元，而一个线程的多个线程在执行过程中共享内存。</p>\r\n\r\n<p>有一个很简单易懂的例子：将CPU比喻成一家正在运作的工厂，而一个车间就代表一个进程，而车间里的工人代表线程，工人们协同完成任务。车间的空间是工人们共享的，比如许多房间是每个工人都可以进出的。这象征一个进程的内存空间是共享的，每个线程都可以使用这些共享内存。</p>\r\n\r\n<p>可是，每间房间的大小不同，有些房间最多只能容纳一个人，比如厕所。里面有人的时候，其他人就不能进去了。这代表一个线程使用某些共享内存时，其他线程必须等它结束，才能使用这一块内存。一个防止他人进入的简单方法，就是门口加一把锁。先到的人锁上门，后到的人看到上锁，就在门口排队，等锁打开再进去。这就叫<strong>互斥锁（Mutual exclusion，缩写 Mutex）</strong>，防止多个线程同时读写某一块内存区域。</p>\r\n\r\n<p>还有些房间，可以同时容纳n个人，比如厨房。也就是说，如果人数大于n，多出来的人只能在外面等着。这好比某些内存区域，只能供给固定数目的线程使用。这时的解决方法，就是在门口挂n把钥匙。进去的人就取一把钥匙，出来时再把钥匙挂回原处。后到的人发现钥匙架空了，就知道必须在门口排队等着了。这种做法叫做<strong>信号量（Semaphore）</strong>，用来保证多个线程不会互相冲突。不难看出，mutex是semaphore的一种特殊情况（n=1时）。也就是说，完全可以用后者替代前者。但是，因为mutex较为简单，且效率高，所以在必须保证资源独占的情况下，还是采用这种设计。因此：</p>\r\n\r\n<ul>\r\n	<li>多进程就是CPU同时运行多个任务。</li>\r\n	<li>多线程则是单个任务分为不同的部分运行。</li>\r\n	<li>进程和线程之间提供协调机制，一方面防止进程之间和线程之间产生冲突，另一方面允许进程之间和线程之间共享资源。</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2. Python多进程的运用&nbsp;</strong></p>\r\n\r\n<p><strong>multiprocessing</strong>是Python提供的编写多进程程序的模块，而该模块中提供了一个Process的类来代表一个进程对象。先来看看普通情况下执行一个大型循环需要多少时间。</p>\r\n\r\n<pre>\r\n<code class=\"language-python\">import os\r\n\r\ndef loop_func(i):\r\n    print(\'Run task {}, Child process number({})...\'.format(i, os.getpid()))\r\n    a = 1\r\n    for i in range(2, 100000):\r\n        a *= i\r\n    return a\r\nif __name__ == \"__main__\":\r\n    print(\"Parent process: {}.\".format(os.getpid()))\r\n    start = time.time()\r\n    for i in range(1, 3):\r\n        p = loop_func(i)\r\n    end = time.time()\r\n    print(\"Child process end.\")\r\n    print(\"Task runs {} seconds.\".format(end - start))\r\n\r\n[out]:\r\nParent process: 14680.\r\nRun task 1, Child process number(14680)...\r\nRun task 2, Child process number(14680)...\r\nChild process end.\r\nTask runs 4.498932600021362 seconds.</code></pre>\r\n\r\n<ul>\r\n	<li>运行两个任务一共使用了将近4.5秒，而且使用的是同一个进程，在看看使用多进程后情况。</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-python\">from multiprocessing import Process,Pool\r\nimport time\r\nimport os\r\n\r\ndef loop_func(i):\r\n    print(\'Run task {}, Child process number({})...\'.format(i, os.getpid()))\r\n    a = 1\r\n    for i in range(2, 100000):\r\n        a *= i\r\n    return a\r\n\r\nif __name__ == \"__main__\":\r\n    print(\"Parent process: {}.\".format(os.getpid()))\r\n    start = time.time()\r\n    p1 = Process(target=loop_func, args=(1,))\r\n    p2 = Process(target=loop_func, args=(1,))\r\n    print(\"Child process will start.\")\r\n    p1.start()\r\n    p2.start()\r\n    p1.join()\r\n    p2.join()\r\n    end = time.time()\r\n    print(\"Child process end.\")\r\n    print(\"Task runs {} seconds.\".format(end - start))\r\n\r\n[out]:\r\nParent process: 12324.\r\nChild process will start.\r\nRun task 1, Child process number(9868)...\r\nRun task 1, Child process number(9888)...\r\nChild process end.\r\nTask runs 2.81182599067688 seconds.</code></pre>\r\n\r\n<ul>\r\n	<li>使用两个进程P1、P2来同时完成任务，Process接收两个参数，一个是target就是你需要运行的任务函数，另一个是任务的参数。</li>\r\n	<li>使用start()开始执行任务，join()来j让母进程阻塞，等待子进程运行结束。</li>\r\n	<li>从运行结果中，我们可以看出，运行时间缩短了一半。</li>\r\n</ul>\r\n\r\n<p>如果大量使用进程的情况下，我们还可以使用进程池Pool的方式批量创建进程。使用方法如下：</p>\r\n\r\n<pre>\r\n<code class=\"language-python\">from multiprocessing import Process,Pool\r\nimport time\r\nimport os\r\ndef loop_func1(i):\r\n    start = time.time()\r\n    print(\'Run task {}, Child process number({})...\'.format(i, os.getpid()))\r\n    a = 1\r\n    for i in range(2, 100000):\r\n        a *= i\r\n    end = time.time()\r\nif __name__ == \"__main__\":\r\n    print(\"Parent process: {}.\".format(os.getpid()))\r\n    start = time.time()\r\n    p = Pool(4)\r\n    for i in range(1, 6):\r\n        p.apply_async(loop_func1, args=(i,))\r\n    print(\"Child process will start.\")\r\n    p.close()\r\n    p.join()\r\n    end = time.time()\r\n    print(\"Child process end.\")\r\n    print(\"Total time {} .\".format(end-start))\r\n\r\n[out]:\r\nParent process: 14248.\r\nChild process will start.\r\nRun task 1, Child process number(12064)...\r\nRun task 2, Child process number(4268)...\r\nRun task 3, Child process number(7720)...\r\nRun task 4, Child process number(4680)...\r\nTask runs 2.3275718688964844 seconds.\r\nRun task 5, Child process number(12064)...\r\nTask runs 2.3275718688964844 seconds.\r\nTask runs 2.3275718688964844 seconds.\r\nTask runs 2.702481746673584 seconds.\r\nTask runs 2.28073787689209 seconds.\r\nChild process end.\r\nTotal time 4.764461517333984 seconds.</code></pre>\r\n\r\n<ul>\r\n	<li><strong>apply_async&nbsp;</strong>作用是向进程池提交需要执行的函数及参数， 各个进程采用非阻塞（异步）的调用方式，即每个子进程只管运行自己的，不管其它进程是否已经完成。</li>\r\n	<li><strong>close()</strong> 用于关闭进程池（pool），使其不在接受新的任务。</li>\r\n	<li><strong>terminate()</strong> 结束工作进程，不在处理未处理的任务。</li>\r\n	<li><strong>join() </strong>主进程阻塞等待子进程的退出， join方法要在close或terminate之后使用。</li>\r\n	<li>使用了四个进程同时执行五个任务，五个任务共花费了4.8秒</li>\r\n	<li>从运行结果中，可以看出，该程序一次同时执行四个任务（CPU核心数代表计算机能同时执行的任务数，可以通过更改p=Pool(x)来实现），而剩下的任务需要在后面排队等待执行结束。</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>3. 进程之间的通信</strong></p>\r\n\r\n<p><code>Process</code>之间肯定是需要通信的，操作系统提供了很多机制来实现进程间的通信。Python的<code>multiprocessing</code>模块包装了底层的机制，提供了<code>Queue</code>、<code>Pipes</code>等多种方式来交换数据。我们以<code>Queue</code>为例，在父进程中创建两个子进程，一个往<code>Queue</code>里写数据，一个从<code>Queue</code>里读数据：</p>\r\n\r\n<pre>\r\n<code class=\"language-python\">from multiprocessing import Process, Queue\r\nimport os, time, random\r\ndef write(q):\r\n    print(\'Process to write: %s\' % os.getpid())\r\n    for value in [\'A\', \'B\', \'C\']:\r\n        print(\'Put %s to queue...\' % value)\r\n        q.put(value)\r\n        time.sleep(random.random())\r\n\r\ndef read(q):\r\n    print(\'Process to read: %s\' % os.getpid())\r\n    while True:\r\n        value = q.get(True)\r\n        print(\'Get %s from queue.\' % value)\r\n\r\nif __name__==\'__main__\':\r\n    q = Queue()\r\n    pw = Process(target=write, args=(q,))\r\n    pr = Process(target=read, args=(q,))\r\n    pw.start()\r\n    pr.start()\r\n    pw.join()\r\n    pr.terminate()\r\n\r\n[out]:\r\nProcess to write: 36589\r\nPut A to queue...\r\nProcess to read: 36590\r\nGet A from queue.\r\nPut B to queue...\r\nGet B from queue.\r\nPut C to queue...\r\nGet C from queue.</code></pre>','2019-12-18 08:47:51.963395','2019-12-18 08:47:51.966874',1,55,1,0,''),(14,'算法笔记—广度优先搜索','<p><strong>一、什么是广度优先搜索</strong></p>\r\n\r\n<p><strong>广度优先搜索</strong>（英语：Breadth-First-Search，缩写为BFS），是一种图形搜索算法。简单的说，BFS是从根节点开始，沿着树的宽度遍历树的节点。如果所有节点均被访问，则算法中止。</p>\r\n\r\n<p><img alt=\"\" src=\"https://cdn.pixabay.com/photo/2012/04/15/19/12/binary-34975__340.png\" style=\"height:171px; width:150px\" /></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>二、BFS工作原理及步骤</strong></p>\r\n\r\n<p>1. 工作原理</p>\r\n\r\n<p>BFS是一种<strong>盲目搜索法</strong>，目的是系统地展开并检查图中的所有节点，以找寻结果。换句话说，它并不考虑结果的可能地址，彻底地搜索整张图，直到找到结果为止。</p>\r\n\r\n<p>从算法的观点，所有因为展开节点而得到的子节点都会被加进一个先进先出的队列中。一般的实现里，其邻居节点尚未被检验过的节点会被放置在一个被称为&nbsp;<em>open</em>&nbsp;的容器中（例如队列或是链表），而被检验过的节点则被放置在被称为&nbsp;<em>closed</em>&nbsp;的容器中，这样可以避免重复检查，陷入死循环。</p>\r\n\r\n<p>2. 使用步骤</p>\r\n\r\n<ul>\r\n	<li>实现图，图<strong>（用来表示物件与物件之间的关系一种方法）</strong>由多个节点组成，每个节点都有相邻节点连接，我们可以使用散列表表示这种关系。</li>\r\n	<li>创建一个队列用于存储需要检查的节点。</li>\r\n	<li>从队列中弹出需要检查的节点，然后检查这个节点是否是我们需要的节点。如果是则搜索完成，如果不是则将其子节点加入队列继续搜索。</li>\r\n	<li>不断重复第三个步骤，直至队列为空。</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>三、Python如何实现BFS</strong></p>\r\n\r\n<p>1. 首先我们使用散列表（也就是Python字典）来实现一个图</p>\r\n\r\n<ul>\r\n	<li>假设我们有一个父节点a，a下面还有有几个子节点，子节点下又有几个子节点，来实现这样一个图</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-python\"># 实现图\r\ngraph = {}\r\ngraph[\'a\'] = [\'b\', \'c\', \'d\']\r\ngraph[\'b\'] = [\'e\', \'f\']\r\ngraph[\'c\'] = [\'g\', \'h\']\r\ngraph[\'d\'] = [\'i\', \'j\']\r\ngraph[\'e\'] = [] #这里所有最底层的子节点也要全定义为空\r\n....\r\nprint(graph)\r\n\r\n[out]:\r\n{\'a\': [\'b\', \'c\', \'d\'], \'b\': [\'e\', \'f\'], \'c\': [\'g\', \'h\'], \'d\': [\'i\', \'j\'], \'e\': [], \'f\': [], \'g\': [], \'h\': [], \'i\': [], \'j\': []}</code></pre>\r\n\r\n<p>2. 接下来我们使用Python库collections的deque来创建一个队列</p>\r\n\r\n<ul>\r\n	<li>创建一个队列，并将a下的子节点加入队列中、</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-python\">from collections import deque\r\nsearch_queue = deque()\r\nsearch_queue += graph[\'a\']\r\nprint(search_queue)\r\n\r\n[out]:\r\ndeque([\'b\', \'c\', \'d\'])</code></pre>\r\n\r\n<p>3. 实现主要逻辑</p>\r\n\r\n<ul>\r\n	<li>既然我们是搜索，当然要有目标啊，不然将整个队列搜完有什么用，因此，我们应该定义一个函数，来让我们达到预期的目标。比如说，如果我们想要搜索的目标是&nbsp;<strong>j 。</strong>那么当搜索到J的时候，我们的整个搜索任务也就完成了，不必在往下搜索了。</li>\r\n</ul>\r\n\r\n<pre>\r\n<code class=\"language-python\">def item_is_target(item):\r\n	return item == \'j\'</code></pre>\r\n\r\n<ul>\r\n	<li>函数中，如果传入的参数是正确的参数，则返回True，反之则返回False。</li>\r\n	<li>定义算法主体。</li>\r\n</ul>\r\n<pre>\r\n<code class=\"language-python\">def search(parent_port):\r\n	search_queue = deque()\r\n	search_queue += graph[parent_port]\r\n	searched = [] #创建一个列表用于存储检查过的值，避免重复检查\r\n	while search_queue:\r\n		item = search_queue.popleft()\r\n		if item not in searched:\r\n			if item_is_target(item):\r\n				print(\"{},is right.\".format(item))\r\n				return True\r\n			else:\r\n				search_queue += graph[item] #将该节点的子节点加入队列\r\n				searched.append(item)\r\n	return False\r\n\r\nsearch(\'a\')\r\n[out]:\r\nj,is right.</code></pre>\r\n<ul>\r\n	<li>搜索结果正确。</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>四、特性</strong></p>\r\n\r\n<p>时间复杂度：在BFS中，我们总是从一个节点到一个节点这么搜索，点与点之间有边来连接，那么我们的运行时间至少为O(边数)。其中我们还使用了队列，包含我们需要检查的每一个节点，将一个人添加到队列的时间是固定的，需要O(1)。因此，我们如果对每个节点都添加的话，则需要O(节点数)。结论，BFS运行时间为O(节点数+边数)，通常些为O(V+E)，V为节点数，E为边数。</p>\r\n\r\n<p>空间复杂度：略。</p>','2019-12-22 13:16:07.990113','2019-12-22 13:21:04.190080',1,53,1,0,''),(15,'算法笔记—狄克斯特拉算法','<p><span style=\"font-size:16px\">上一章中，学习了广度优先搜索如何工作的，但是我的笔记好像只注重其搜索功能的实现，而没有提它解决最短路径的方法。实际上同我们介绍的原理，就能想到它还能这么用：将我们的子节点后面添加一个终点，所有的子节点最终都会走到终点，而BFS搜到距离父节点最近的终点以后就会停止，从而得到最短路径。</span></p>\r\n\r\n<p><span style=\"font-size:16px\">但是BFS解决的最短路径问题局限性较大，需要节点与节点之间的边的<span style=\"background-color:#2ecc71\">权数</span>是相同的。如果我们需要对每一条边都赋权的情况，就需要用到<span style=\"background-color:#2ecc71\">狄克斯特拉算法</span>。</span></p>\r\n\r\n<p><span style=\"font-size:16px\">一、什么是狄克斯特拉算法</span></p>\r\n\r\n<p><span style=\"font-size:16px\"><strong>狄克斯特拉算法</strong>（英语：Dijkstra&#39;s algorithm）由荷兰计算机科学家艾兹赫尔&middot;狄克斯特拉在1956年提出。狄克斯特拉算法使用了广度优先搜索解决赋权有向图的单源最短路径问题。该算法存在很多变体；狄克斯特拉的原始版本找到两个顶点之间的最短路径，但是更常见的变体固定了一个顶点作为源节点然后找到该顶点到图中所有其它节点的最短路径，产生一个最短路径树。该算法常用于路由算法或者作为其他图算法的一个子模块</span></p>\r\n\r\n<p><span style=\"font-size:16px\">二、算法运行原理及步骤</span></p>\r\n\r\n<ol>\r\n	<li><span style=\"font-size:16px\">Dijkstra算法采用的是一种贪心的策略，声明一个数组dis来保存源点到各个顶点的最短距离和一个保存已经找到了最短路径的顶点的集合：T，初始时，原点 s 的路径权重被赋为 0 （dis[s] = 0）。若对于顶点 s 存在能直接到达的边（s,m），则把dis[m]设为w（s, m）,同时把所有其他（s不能直接到达的）顶点的路径长度设为无穷大。初始时，集合T只有顶点s。从dis数组选择最小值，则该值就是源点s到该值对应的顶点的最短路径，并且把该点加入到T中，OK，此时完成一个顶点，我们需要看看新加入的顶点是否可以到达其他顶点并且看看通过该顶点到达其他点的路径长度是否比源点直接到达短，如果是，那么就替换这些顶点在dis中的值。最后，又从dis中找出最小值，重复上述动作，直到T中包含了图的所有顶点。</span></li>\r\n	<li><span style=\"font-size:16px\">运行步骤：</span></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:16px\">找出距离最短、或是权重最小的节点。</span></li>\r\n	<li><span style=\"font-size:16px\">更新该节点的邻居节点的开销。</span></li>\r\n	<li><span style=\"font-size:16px\">重复这个过程，直到对图中的每个节点都这样做。</span></li>\r\n	<li><span style=\"font-size:16px\">计算出最终路径。</span></li>\r\n</ul>\r\n\r\n<p><span style=\"font-size:16px\">三、Python实现狄克斯特拉算法</span></p>\r\n\r\n<p>例子：假设我们有四个节点起点、A、B、终点。起点到A的权数为6，到B的权数为2，A到终点的权数为1，B到终点的权数为5，B还可以到A，权数为3。求起点到终点的最短路径。</p>\r\n\r\n<p>1. 首先我们整理数据，将信息放入三个表中：</p>\r\n\r\n<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:200px\">\r\n	<caption>Graph</caption>\r\n	<tbody>\r\n		<tr>\r\n			<td><span style=\"display:none\">&nbsp;</span>起点</td>\r\n			<td>A</td>\r\n			<td>6</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>B</td>\r\n			<td>2</td>\r\n		</tr>\r\n		<tr>\r\n			<td>A</td>\r\n			<td>终点</td>\r\n			<td>1</td>\r\n		</tr>\r\n		<tr>\r\n			<td>B</td>\r\n			<td>A</td>\r\n			<td>3</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>终点</td>\r\n			<td>5</td>\r\n		</tr>\r\n		<tr>\r\n			<td>终点</td>\r\n			<td>&nbsp;</td>\r\n			<td>-</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;Graph表中放着图的所有信息，也是算法的数据来源。</p>\r\n\r\n<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:150px\">\r\n	<caption>Costs</caption>\r\n	<tbody>\r\n		<tr>\r\n			<td>A</td>\r\n			<td>6</td>\r\n		</tr>\r\n		<tr>\r\n			<td>B</td>\r\n			<td>2</td>\r\n		</tr>\r\n		<tr>\r\n			<td>终点</td>\r\n			<td>INF</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Costs用来不断更新数据，以此来获得最短的距离。&nbsp;</p>\r\n\r\n<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:150px\">\r\n	<caption>Parents</caption>\r\n	<tbody>\r\n		<tr>\r\n			<td>A</td>\r\n			<td>起点</td>\r\n		</tr>\r\n		<tr>\r\n			<td>B</td>\r\n			<td>起点</td>\r\n		</tr>\r\n		<tr>\r\n			<td>终点</td>\r\n			<td>-</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>Parents用来存储父节点，用于记录我们所经过的路径。</p>\r\n\r\n<p>将这三个表用Python表示出来，这里使用字典嵌套的方式表达点到点的关系，表示路径。&nbsp;Graph表代码如下：</p>\r\n\r\n<pre>\r\n<code class=\"language-python\">graph = {}\r\ngraph[\'start\'] = {}\r\ngraph[\'start\'][\'a\'] = 6\r\ngraph[\'start\'][\'b\'] = 2\r\ngraph[\'a\'] = {}\r\ngraph[\'a\'][\'fin\'] = 1\r\ngraph[\'b\'] = {}\r\ngraph[\'b\'][\'a\'] = 3\r\ngraph[\'b\'][\'fin\'] = 5\r\ngraph[\'fin\'] = {}</code></pre>\r\n\r\n<p>Costs表：</p>\r\n\r\n<pre>\r\n<code class=\"language-python\">infinity = float(\'inf\')\r\ncosts = {}\r\ncosts[\'a\'] = 6\r\ncosts[\'b\'] = 2\r\ncosts[\'fin\'] = infinity</code></pre>\r\n\r\n<p>Parents表：</p>\r\n\r\n<pre>\r\n<code class=\"language-python\">parents = {}\r\nparents[\'a\'] = \'start\'\r\nparents[\'b\'] = \'start\'\r\nparents[\'fin\'] = None</code></pre>\r\n\r\n<p>2. 找到起点到相邻的距离最短的点</p>\r\n\r\n<pre>\r\n<code class=\"language-python\">processed = []\r\ndef find_lowest_costs_node(costs):\r\n    lowest_cost = float(\'inf\')\r\n    lowest_cost_node = None\r\n    for node in costs:\r\n        cost = costs[node]\r\n        if cost &lt; lowest_cost and node not in processed:\r\n            lowest_cost = cost\r\n            lowest_cost_node = node\r\n    return  lowest_cost_node</code></pre>\r\n\r\n<p>3. 更新开销，并找出最短距离。</p>\r\n\r\n<pre>\r\n<code class=\"language-python\">def dijkstra_algorithm(costs):\r\n    node = find_lowest_costs_node(costs)\r\n    while node is not None:\r\n        print(node)\r\n        cost = costs[node]\r\n        neighbors = graph[node]\r\n        for n in neighbors.keys():\r\n            new_cost = cost + neighbors[n]\r\n            if costs[n] &gt; new_cost:\r\n                costs[n] = new_cost\r\n                parents[n] = node\r\n        processed.append(node)\r\n        node = find_lowest_costs_node(costs)\r\n        print(parents)\r\ndijkstra_algorithm(costs)\r\n\r\n[out]:\r\nb\r\n{\'a\': \'b\', \'b\': \'start\', \'fin\': \'b\'}\r\na\r\n{\'a\': \'b\', \'b\': \'start\', \'fin\': \'a\'}\r\nfin\r\n{\'a\': \'b\', \'b\': \'start\', \'fin\': \'a\'}</code></pre>\r\n\r\n<ul>\r\n	<li>从输出我们可以看出，程序先出找到 了权数最小也是距离最短的B点，通过B点相邻的点去更新Costs表和Parents表。</li>\r\n	<li>B更新完以后，将B从更新表中剔除，用A在来更新，如果找到更短的距离，则更新两表。</li>\r\n	<li>最后是使用终点更新，因为没有子节点，因此，和以前的输出不变。</li>\r\n</ul>\r\n\r\n<p><span style=\"font-size:16px\">四、学习感悟</span></p>\r\n\r\n<p><span style=\"background-color:#2ecc71\">狄克斯特拉算法</span>我觉得是一种比较有用的算法，相比于广度优先搜索来说，它更能运用于实际的生活中。当然是用于更复杂的计算，将其推广到一个较为复杂的最短距离问题，而不是例子上的四个点问题。而且其时间复杂度为O(n<sup>2</sup>)，相对来说也较为合理。感觉目前还不是很熟悉，后面还需要用更大点的例子来练习这个算法。而且这篇学习笔记写的冲忙，还有很多的不足之处需要修改。争取让笔记能够通俗易懂，方便以后复习查阅。</p>\r\n\r\n<p>&nbsp;</p>','2019-12-23 08:51:59.671223','2019-12-23 08:51:59.676771',1,42,1,0,''),(16,'Python如何实现链表结构','<p><strong><span style=\"font-size:16px\">一、前言</span></strong></p>\r\n\r\n<p><span style=\"font-size:16px\">近日在<span style=\"background-color:#1abc9c\">Leetcode</span>刷题才深感自身的不足，学了那么久的Python其实用到的表达方法很是基础，看别人题解的时候，一些方法平时自己都没有接触到。所以近来一边学习算法，一边恶补新的知识。感觉Leetcode这个平台对我的帮助蛮大的，让我看清楚我和别人的差距，知道自己要走的路还有很长，同时也激励自己不断的进步。</span></p>\r\n\r\n<p><span style=\"font-size:16px\">算法和数据结构一直以来都是计算机编程的基本功，算法是提升我们解决问题效率的关键，而数据结构又是实现算法的一种工具。今天我们就来记录一下Python实现数据结构中<span style=\"background-color:#1abc9c\">链表</span>的心得。</span></p>\r\n\r\n<p><strong><span style=\"font-size:16px\">二、什么是链表</span></strong></p>\r\n\r\n<p><span style=\"font-size:16px\">对于什么是链表这样一个专业的话题，本该去维基百科抄一点过来，这样才能显得专业一点（以前我也是这样做的，名词解释一般选择抄），但想着仅仅是个人笔记，需要的是个人易于理解的话来解释可能对自己的帮助更大一些。</span></p>\r\n\r\n<p><span style=\"font-size:16px\"><img alt=\"链表结构\" src=\"https://pic3.zhimg.com/v2-8158f5bef33b4d38c0ff43d11139a003_1200x500.jpg\" style=\"width:100%\" /></span></p>\r\n\r\n<p><span style=\"font-size:16px\">首先来举一个例子：假设你去上课，你自己先到了，像个的室友们占位置，但是你不知道你的懒鬼室友到底会不会来上课，你又不能一直占着位置，因为其他同学还要坐。所以只能分开坐，来一个做一个，你记录你下一个来的室友，而下一个室友记录下一个室友，这样就能记录下所有室友的位置了。虽然例子有点沙雕，但是道理还是这么个道理，链表每一个节点记录着两个信息，一个是自己的值，另一个是下一个节点的位置。这样找到一个就能找到下一个，当然这种顺序是不可逆的，而且必须从第一个开始查找。不像数组（Python列表）一样都是坐在一排的，第几个是谁都知道可以直接取出来。但链表也有他的厉害之处，<span style=\"background-color:#1abc9c\">删除、修改、添加</span>都可以一步到位<span style=\"background-color:#1abc9c\">O(1)</span>，而<span style=\"background-color:#1abc9c\">查找</span>则需要N步<span style=\"background-color:#1abc9c\">O(n)</span>。而数组恰好相反，查找为<span style=\"background-color:#1abc9c\">O(1)</span>，<span style=\"background-color:#1abc9c\">增删</span>改需要<span style=\"background-color:#1abc9c\">O(n)</span>。</span></p>\r\n\r\n<p><strong><span style=\"font-size:16px\">三、Python实现链表</span></strong></p>\r\n\r\n<p><strong><span style=\"font-size:16px\">1. 首先可以用类构造一个链表的模型</span></strong></p>\r\n\r\n<pre>\r\n<code class=\"language-python\">class ListNode():\r\n    def __init__(self, x):\r\n        self.val = x\r\n        self.next = None\r\n</code></pre>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:16px\">val表示该节点值，next表示其指向的下一个节点</span></li>\r\n</ul>\r\n\r\n<p><strong><span style=\"font-size:16px\">2. 构建链表的功能， 实现增删</span></strong></p>\r\n\r\n<p><span style=\"font-size:16px\">（1）增加节点</span></p>\r\n\r\n<pre>\r\n<code class=\"language-python\">class ListNodeFun():\r\n    def __init__(self):\r\n        self.head = None\r\n\r\n    # 链表前面添加元素\r\n    def addleft(self, newdata:str):\r\n        newlistnode = ListNode(newdata)\r\n        newlistnode.next = self.head\r\n        self.head = newlistnode        \r\n    \r\n    #在链表中间插入内容\r\n    def insert(self, mid, newdata):\r\n        if not mid:\r\n            print(\"Are you sure you have input references!\")\r\n            return\r\n        newlistnode = ListNode(newdata)\r\n        newlistnode.next = mid.next\r\n        mid.next = newlistnode\r\n        \r\n    #在链表后面添加元素\r\n    def append(self, newdata:str):\r\n        newlistnode = ListNode(newdata)\r\n        if self.head is None:\r\n            self.head = newlistnode\r\n            return\r\n        last = self.head\r\n        while last.next:\r\n            last = last.next\r\n        last.next = newlistnode</code></pre>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:16px\">前面添加：在链表的最前方添加节点比较简单，直接将原第一个节点的位置记录给新增的几点，并将Head表示赋予新节点。方便我们能找到第一个节点。</span></li>\r\n	<li><span style=\"font-size:16px\">中间插入：我们需要给函数两个参数，一个是参考值需要插入的位置，即某个节点后；二是需要新节点的值。思路是，将参考值记录的下一个的信息给新值，将新增的信息给参考值。</span></li>\r\n	<li><span style=\"font-size:16px\">末尾插入：末尾插入也简单，将链表遍历一遍，将新值的信息记录给链表的最后一个值即可。</span></li>\r\n</ul>\r\n\r\n<p><span style=\"font-size:16px\">（2）删除节点</span></p>\r\n\r\n<pre>\r\n<code class=\"language-python\">class ListNodeFun():\r\n    ...\r\n    \r\n    #删除元素\r\n    def delete(self, delval):\r\n        headlk = self.head\r\n        if not delval:\r\n            print(\"Are you sure have this node?\")\r\n            return\r\n        if headlk.val == delval:\r\n            self.head = headlk.next\r\n            headlk = None\r\n            return\r\n        while headlk:\r\n            nextlk = headlk.next\r\n            if nextlk.val == delval:\r\n                headlk.next = nextlk.next\r\n                nextlk = None\r\n                break\r\n            headlk = headlk.next    </code></pre>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:16px\">删除我们考虑两种情况，第一种是删除链表的第一个节点，第二种是删除其余任意节点。</span></li>\r\n	<li><span style=\"font-size:16px\">第一种：将Head标识给第一个节点的下一个节点，然后删除第一个节点，即可删除第一个节点。</span></li>\r\n	<li><span style=\"font-size:16px\">第二种：将要删除的节点的上一个节点记录的信息改为该节点的下一个节点的值即可。</span></li>\r\n</ul>\r\n\r\n<p><span style=\"font-size:16px\">（3）打印链表内容</span></p>\r\n\r\n<pre>\r\n<code class=\"language-python\">class ListNodeFun():\r\n    ...\r\n        \r\n    #打印出链表\r\n    def showlinkedlist(self):\r\n        printval = self.head\r\n        while printval:\r\n            print(printval.val)\r\n            printval = printval.next</code></pre>\r\n\r\n<p><span style=\"font-size:16px\">（4）用实例测试一下我们的链表</span></p>\r\n\r\n<pre>\r\n<code class=\"language-python\">if __name__ == \"__main__\":\r\n    lnf = ListNodeFun()\r\n    lnf.head = ListNode(\'li\')\r\n    node2 = ListNode(\"gang\")\r\n    lnf.head.next = node2\r\n    lnf.append(\'limouyin\')\r\n    lnf.addleft(\'fengdaren\')\r\n    lnf.insert(node2,\'gang2\') #在node2后面添加节点‘gang’\r\n    lnf.delete(\'li\') #删除值‘li’\r\n    lnf.showlinkedlist()\r\n[out]:\r\nfengdaren\r\ngang\r\ngang2\r\nlimouyin</code></pre>\r\n\r\n<p><span style=\"font-size:16px\">输出很简单，证明我们的链表正常工作了。</span></p>\r\n\r\n<p><strong><span style=\"font-size:16px\">四、总结</span></strong></p>\r\n\r\n<p><span style=\"font-size:16px\">第一次实现一个数据结构，想想还是有点小激动的呢！后面还要继续加油，熟悉算法和数据结构任重而道远。</span></p>','2019-12-28 06:37:31.427406','2020-03-06 02:17:40.332142',1,49,1,2,''),(17,'Python垃圾回收机制','<p><strong><span style=\"font-size:16px\">一、概述</span></strong></p>\r\n\r\n<p><span style=\"font-size:16px\">Python是一门以简洁著称的语言，所以很多语言功能Python都已经给我们包装好了的，这也是为什么它对新手十分友好的原因。比如说直接对名称赋值，而不必声明类型。名称类型的确定、内存空间的分配与释放都是由Python解释器在运行时进行的。Python虽然能自动管理内存，但了解其运行机制对于我们理解Python具有重要意义。<strong>在Python中，主要通过引用计数进行垃圾回收；通过 &ldquo;标记-清除&rdquo; 解决容器对象可能产生的循环引用问题；通过 &ldquo;分代回收&rdquo; 以空间换时间的方法提高垃圾回收效率。</strong></span></p>\r\n<p><span style=\"font-size:16px\"><strong><img alt=\"\" src=\"https://img.php.cn/upload/article/000/000/003/5d1c74734f6d7600.jpg\" style=\" width:100%\" /></strong></span></p>\r\n<p><span style=\"font-size:16px\"><strong>二、引用计数</strong></span></p>\r\n\r\n<p><span style=\"font-size:16px\">Python主要采用<span style=\"background-color:#1abc9c\">引用计数</span>的方式实现垃圾回收。</span></p>\r\n\r\n<pre>\r\n<code class=\"language-c\">typedef struct_object {\r\n int ob_refcnt;\r\n struct_typeobject *ob_type;\r\n} PyObject;</code></pre>\r\n\r\n<p><span style=\"font-size:16px\">虽然我看不懂什么意思，但是不影响我强行解释一下。在Python中每一个对象的核心就是一个结构体PyObject，它的内部有一个引用计数器（ob_refcnt）。程序在运行的过程中会实时的更新ob_refcnt的值，来反映引用当前对象的名称数量。当某对象的引用计数值为0,那么它的内存就会被立即释放掉。</span></p>\r\n\r\n<p><span style=\"font-size:16px\">计数顾名思义当然要有增有减了，那这个对象的计数什么时候增加什么时候减少呢？</span></p>\r\n\r\n<p><span style=\"font-size:16px\">计数增加1的情况：</span></p>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:16px\">对象被创建的时候。例如：a = Ob() 后者 a = 1时</span></li>\r\n	<li><span style=\"font-size:16px\">对象被其他对象引用的时候。例如：b = a</span></li>\r\n	<li><span style=\"font-size:16px\">对象被作为参数调用时，计数会加一；但是调用结束以后，参数就离开他的作用域，就会减一。例如func(a)</span></li>\r\n	<li><span style=\"font-size:16px\">对象被存储进容器时。例如list1&nbsp;= [a]</span></li>\r\n</ul>\r\n\r\n<p><span style=\"font-size:16px\">看个例子：</span></p>\r\n\r\n<pre>\r\n<code class=\"language-python\">import sys\r\nclass Ob:\r\n	def __init__(self):\r\n		pass\r\ndef func(n):\r\n	print(\'Run into function：\',sys.getrefcount(n)-1)\r\n\r\na = Ob() #创建对象 +1\r\nb = a  #引用对象 +1\r\nlist1 = [a] #存入容器 +1\r\nfunc(a)  #函数引用 +1 但是函数结束后会减1\r\nprint(\'Count:\',sys.getrefcount(a)-1) \r\n[out]:\r\nRun into function： 5\r\nCount: 3</code></pre>\r\n\r\n<p><span style=\"font-size:16px\">计数减少1的情况：</span></p>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:16px\">对象别名被显示销毁。例如：del a</span></li>\r\n	<li><span style=\"font-size:16px\">对象别名被赋予新的对象。例如：a = Ob1()</span></li>\r\n	<li><span style=\"font-size:16px\">一个对象离开他的作用域。例如一个函数运行结束以后。</span></li>\r\n	<li><span style=\"font-size:16px\">对象所在的容器被销毁或者是从容器中删除对象。例如：del list1</span></li>\r\n</ul>\r\n\r\n<p><span style=\"font-size:16px\">接上面的例子：</span></p>\r\n\r\n<pre>\r\n<code class=\"language-python\">import sys\r\n....\r\nclass Ob1:\r\n	def __init__(self):\r\n		pass\r\n\r\n....\r\na = Ob1()\r\nprint(\'Count:\',sys.getrefcount(a)-1)\r\n[out]:\r\nCount: 1</code></pre>\r\n\r\n<p><span style=\"font-size:16px\"><span style=\"background-color:#1abc9c\">引用计数的优点：</span>高效、实现逻辑简单、具备实时性，一旦一个对象的引用计数归零，内存就直接释放了。不用像其他机制等到特定时机。将垃圾回收随机分配到运行的阶段，处理回收内存的时间分摊到了平时，正常程序的运行比较平稳。<span style=\"background-color:#1abc9c\">缺点：</span>实现有些麻烦。每个对象需要分配单独的空间来统计引用计数，这无形中加大的空间的负担，并且需要对引用计数进行维护，在维护的时候很容易会出错。释放大的对象时需要对引用的所有对象循环嵌套调用，从而可能会花费比较长的时间。循环引用。这将是引用计数的致命伤，引用计数对此是无解的，因此必须要使用其它的垃圾回收算法对其进行补充。</span></p>\r\n\r\n<p><strong><span style=\"font-size:16px\">三、标记清除解决循环引用</span></strong></p>\r\n\r\n<p><span style=\"font-size:16px\">该辅助算法分为两步第一步是标记，第二步是清除<span style=\"background-color:#1abc9c\">（废话）</span>：</span></p>\r\n\r\n<ul>\r\n	<li><span style=\"font-size:16px\">A）标记阶段，遍历所有的对象，如果是可达的（reachable），也就是还有对象引用它，那么就标记该对象为可达；</span></li>\r\n	<li><span style=\"font-size:16px\">B）清除阶段，再次遍历对象，如果发现某个对象没有标记为可达，则就将其回收。</span></li>\r\n</ul>\r\n\r\n<p><span style=\"font-size:16px\">总结来说就是：准备两个链表，一个为待扫描的链表，一个为不可达的链表。将容器对象放入待扫描的链表中，假设有ABC三个对象，A引用了B，B引用了C，C引用了A，构成一个循环引用，除此之外，还有一个东西引用了A。然后gc启动遍历链表，将当前对象所应用的对象的gc_ref（引用计数副本，作为标记使用）减一，因为是循环引用所以会全部减一，只有A引用了两次，其他都是一次，所以扫描一次后其他gc_ref变为0。A变为1。</span></p>\r\n\r\n<p><span style=\"font-size:16px\">然后再次扫描将gc_ref为0的对象标记为不可达，放入不可达链表。不为零的标记为可达。gc同时会将标记为可达的对象<span style=\"background-color:#1abc9c\">出发（相连/引用）</span>的对象也标记可达。所以会将刚刚放入不可达链表的对象移回来，并标记为可达。随后清除标记为不可达的对象。<span style=\"background-color:#1abc9c\">该过程会暂停程序的运行，等待清除结束。</span>为了减少暂停的时间，我们有引入了一个辅助方法，<span style=\"background-color:#1abc9c\">分代回收</span>。</span></p>\r\n\r\n<p><strong><span style=\"font-size:16px\">四、分代回收</span></strong></p>\r\n\r\n<p><span style=\"font-size:16px\">在循环引用对象的回收中，整个应用程序会被暂停，为了减少应用程序暂停的时间，Python 通过<strong>&ldquo;分代回收&rdquo;(Generational Collection)</strong>以空间换时间的方法提高垃圾回收效率。这种方法主要基于对象存在时间越长越可能不是垃圾的思想。</span></p>\r\n\r\n<p><span style=\"font-size:16px\">该方法将对象分为三代，新的对象放入第一代，这一代扫描次数多，经过扫描存活下来的对象进入第二代，这里次数较少，存活的在进入第三代，这里扫描次数更少。当某一代被扫描的时候，他的前一代也会被扫描。也就是说第三代被扫描的时候，第二代第一代也会别扫描。该阈值可以通过下面两个函数查看和调整:</span></p>\r\n\r\n<pre>\r\n<code class=\"language-python\">gc.get_threshold() # (threshold0, threshold1, threshold2).\r\ngc.set_threshold(threshold0[, threshold1[, threshold2]])</code></pre>\r\n\r\n<p><strong><span style=\"font-size:16px\">五、总结</span></strong></p>\r\n\r\n<p><span style=\"font-size:16px\">Python的垃圾回收主要是通过<span style=\"background-color:#1abc9c\">引用计数</span>的方式来实现。该方法简单易用，但是存在循环引用缺点，为了弥补这个缺点，引入了<span style=\"background-color:#1abc9c\">标记-清除</span>的方法。而标记清除的方法也带来了一个问题，就是标记-清除期间会暂停程序的运行。为了减少暂停时间，我们又引入了<span style=\"background-color:#1abc9c\">分代回收</span>的方法，减少扫描的次数，从而减少暂停时间，提升程序的运行效率。</span></p>','2020-01-09 03:52:26.847729','2020-01-09 06:04:38.952226',1,51,1,0,'');
/*!40000 ALTER TABLE `article_articlepost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add profile',1,'add_profile'),(2,'Can change profile',1,'change_profile'),(3,'Can delete profile',1,'delete_profile'),(4,'Can view profile',1,'view_profile'),(5,'Can add article post',2,'add_articlepost'),(6,'Can change article post',2,'change_articlepost'),(7,'Can delete article post',2,'delete_articlepost'),(8,'Can view article post',2,'view_articlepost'),(9,'Can add article column',3,'add_articlecolumn'),(10,'Can change article column',3,'change_articlecolumn'),(11,'Can delete article column',3,'delete_articlecolumn'),(12,'Can view article column',3,'view_articlecolumn'),(13,'Can add log entry',4,'add_logentry'),(14,'Can change log entry',4,'change_logentry'),(15,'Can delete log entry',4,'delete_logentry'),(16,'Can view log entry',4,'view_logentry'),(17,'Can add permission',5,'add_permission'),(18,'Can change permission',5,'change_permission'),(19,'Can delete permission',5,'delete_permission'),(20,'Can view permission',5,'view_permission'),(21,'Can add group',6,'add_group'),(22,'Can change group',6,'change_group'),(23,'Can delete group',6,'delete_group'),(24,'Can view group',6,'view_group'),(25,'Can add user',7,'add_user'),(26,'Can change user',7,'change_user'),(27,'Can delete user',7,'delete_user'),(28,'Can view user',7,'view_user'),(29,'Can add content type',8,'add_contenttype'),(30,'Can change content type',8,'change_contenttype'),(31,'Can delete content type',8,'delete_contenttype'),(32,'Can view content type',8,'view_contenttype'),(33,'Can add session',9,'add_session'),(34,'Can change session',9,'change_session'),(35,'Can delete session',9,'delete_session'),(36,'Can view session',9,'view_session'),(37,'Can add Tag',10,'add_tag'),(38,'Can change Tag',10,'change_tag'),(39,'Can delete Tag',10,'delete_tag'),(40,'Can view Tag',10,'view_tag'),(41,'Can add Tagged Item',11,'add_taggeditem'),(42,'Can change Tagged Item',11,'change_taggeditem'),(43,'Can delete Tagged Item',11,'delete_taggeditem'),(44,'Can view Tagged Item',11,'view_taggeditem'),(45,'Can add comment',12,'add_comment'),(46,'Can change comment',12,'change_comment'),(47,'Can delete comment',12,'delete_comment'),(48,'Can view comment',12,'view_comment'),(49,'Can add notification',13,'add_notification'),(50,'Can change notification',13,'change_notification'),(51,'Can delete notification',13,'delete_notification'),(52,'Can view notification',13,'view_notification'),(53,'Can add carousel',14,'add_carousel'),(54,'Can change carousel',14,'change_carousel'),(55,'Can delete carousel',14,'delete_carousel'),(56,'Can view carousel',14,'view_carousel');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$150000$qjHWxM852Jih$dOBflCyu46yRzh3mwNOdA/IB3Wgz+V+gObYzmzV0OSI=','2020-04-03 13:17:16.110606',1,'limouyin','','','liganggooo@gmail.com',1,1,'2019-11-29 02:52:47.539878'),(2,'pbkdf2_sha256$150000$zGFYeNMEdtqY$vZ2QIG0VCH66lzhf1eFZYBGhJWJf+brplMuTBvD13GE=','2019-12-18 12:11:17.936169',0,'小李南风','','','3030972867@qq.com',0,1,'2019-12-18 12:11:17.737126'),(3,'pbkdf2_sha256$150000$shnzZ2lIgeXi$tb41mQxxKBnC+i6ly+gXRkI4dc1ptQS/p36lInRiJNk=','2019-12-19 05:15:15.969244',0,'NULL','','','null@gmail.com',0,1,'2019-12-19 05:12:24.020334');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carousel_carousel`
--

DROP TABLE IF EXISTS `carousel_carousel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carousel_carousel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `carousel_img` varchar(100) NOT NULL,
  `source` varchar(20) NOT NULL,
  `title` varchar(50) NOT NULL,
  `subtitle` varchar(100) NOT NULL,
  `img_link` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carousel_carousel`
--

LOCK TABLES `carousel_carousel` WRITE;
/*!40000 ALTER TABLE `carousel_carousel` DISABLE KEYS */;
/*!40000 ALTER TABLE `carousel_carousel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment_comment`
--

DROP TABLE IF EXISTS `comment_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `created` datetime(6) NOT NULL,
  `article_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `level` int(10) unsigned NOT NULL,
  `lft` int(10) unsigned NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `reply_to_id` int(11) DEFAULT NULL,
  `rght` int(10) unsigned NOT NULL,
  `tree_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `comment_comment_article_id_3cc364fc_fk_article_articlepost_id` (`article_id`),
  KEY `comment_comment_user_id_6078e57b_fk_auth_user_id` (`user_id`),
  KEY `comment_comment_parent_id_b612524c` (`parent_id`),
  KEY `comment_comment_reply_to_id_e0adcef8_fk_auth_user_id` (`reply_to_id`),
  KEY `comment_comment_tree_id_42ec2c80` (`tree_id`),
  CONSTRAINT `comment_comment_article_id_3cc364fc_fk_article_articlepost_id` FOREIGN KEY (`article_id`) REFERENCES `article_articlepost` (`id`),
  CONSTRAINT `comment_comment_parent_id_b612524c_fk_comment_comment_id` FOREIGN KEY (`parent_id`) REFERENCES `comment_comment` (`id`),
  CONSTRAINT `comment_comment_reply_to_id_e0adcef8_fk_auth_user_id` FOREIGN KEY (`reply_to_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `comment_comment_user_id_6078e57b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment_comment`
--

LOCK TABLES `comment_comment` WRITE;
/*!40000 ALTER TABLE `comment_comment` DISABLE KEYS */;
INSERT INTO `comment_comment` VALUES (1,'<p>未完待续......</p>','2019-12-05 03:02:55.480494',5,1,0,1,NULL,NULL,2,1),(8,'<p>哇⊙&forall;⊙！写得真棒呀。<img alt=\"wink\" src=\"https://liganggooo.com/static/ckeditor/ckeditor/plugins/smiley/images/wink_smile.png\" style=\"height:23px; width:23px\" title=\"wink\" /></p>','2019-12-18 12:14:06.078304',6,2,0,1,NULL,NULL,2,2),(9,'<p>哇⊙&forall;⊙！写得真棒呀。<img alt=\"wink\" src=\"https://liganggooo.com/static/ckeditor/ckeditor/plugins/smiley/images/wink_smile.png\" style=\"height:23px; width:23px\" title=\"wink\" /></p>','2019-12-18 12:14:15.157882',6,2,0,1,NULL,NULL,2,3),(10,'<p>哇⊙&forall;⊙！，写得很详细呀，而且清晰而有条理，作者一定是一个温柔体贴，很暖的男孩子。欧耶/:v&nbsp;</p>','2019-12-18 12:16:21.088678',5,2,0,1,NULL,NULL,2,4),(11,'<p>你是最胖的作者<img alt=\"cool\" src=\"https://liganggooo.com/static/ckeditor/ckeditor/plugins/smiley/images/shades_smile.png\" style=\"height:23px; width:23px\" title=\"cool\" /></p>','2019-12-19 05:13:38.594862',6,3,0,1,NULL,NULL,2,5),(12,'<p>胖胖哒</p>','2019-12-19 05:13:53.549578',6,3,0,1,NULL,NULL,2,6),(13,'<p><object classid=\"clsid:d27cdb6e-ae6d-11cf-96b8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0\"><param name=\"allowFullScreen\" value=\"true\" /><param name=\"quality\" value=\"high\" /><param name=\"movie\" value=\"https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/Dijkstra_Animation.gif/220px-Dijkstra_Animation.gif\" /><embed allowfullscreen=\"true\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" quality=\"high\" src=\"https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/Dijkstra_Animation.gif/220px-Dijkstra_Animation.gif\" type=\"application/x-shockwave-flash\"></embed></object></p>','2019-12-23 02:52:51.847601',14,1,0,1,NULL,NULL,2,7),(14,'<p><object classid=\"clsid:d27cdb6e-ae6d-11cf-96b8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0\"><param name=\"allowFullScreen\" value=\"true\" /><param name=\"quality\" value=\"high\" /><param name=\"movie\" value=\"https://images2017.cnblogs.com/blog/849589/201710/849589-20171015224719590-1433219824.gif\" /><embed allowfullscreen=\"true\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" quality=\"high\" src=\"https://images2017.cnblogs.com/blog/849589/201710/849589-20171015224719590-1433219824.gif\" type=\"application/x-shockwave-flash\"></embed></object></p>','2019-12-31 01:57:46.015390',12,1,0,1,NULL,NULL,2,8),(15,'<p><img alt=\"indecision\" src=\"https://liganggooo.com/static/ckeditor/ckeditor/plugins/smiley/images/whatchutalkingabout_smile.png\" style=\"height:23px; width:23px\" title=\"indecision\" /></p>','2020-03-13 00:54:04.177237',17,1,0,1,NULL,NULL,2,9);
/*!40000 ALTER TABLE `comment_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2019-11-29 02:55:06.756790','1','程序人生',1,'[{\"added\": {}}]',3,1),(2,'2019-11-29 02:55:39.914672','2','工作/生活',1,'[{\"added\": {}}]',3,1),(3,'2019-11-29 02:56:54.741921','1','工作/生活',1,'[{\"added\": {}}]',2,1),(4,'2019-11-29 02:58:06.353454','1','爽爽的凉都——六盘水',2,'[{\"changed\": {\"fields\": [\"column\", \"title\"]}}]',2,1),(5,'2019-12-11 07:33:47.867172','2','<p><a href=\"http://b',3,'',12,1),(6,'2019-12-11 07:33:47.870641','3','<pre>\r\n<code>$ docke',3,'',12,1),(7,'2019-12-11 07:33:47.873048','4','<p>docker container ',3,'',12,1),(8,'2019-12-11 07:33:47.878261','5','<p><strong>（5）docker',3,'',12,1),(9,'2019-12-11 07:33:47.880719','6','<p>十一、其他有用的命令</p>\r\n\r',3,'',12,1),(10,'2019-12-11 07:41:02.081637','7','<p>六、Docker 的安装</p>\r',3,'',12,1),(11,'2019-12-19 01:27:22.522868','10','<p>哇⊙&forall;⊙！，写得很详',2,'[{\"changed\": {\"fields\": [\"body\"]}}]',12,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (4,'admin','logentry'),(3,'article','articlecolumn'),(2,'article','articlepost'),(6,'auth','group'),(5,'auth','permission'),(7,'auth','user'),(14,'carousel','carousel'),(12,'comment','comment'),(8,'contenttypes','contenttype'),(13,'notifications','notification'),(9,'sessions','session'),(10,'taggit','tag'),(11,'taggit','taggeditem'),(1,'userprofile','profile');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2019-11-29 02:51:49.395160'),(2,'auth','0001_initial','2019-11-29 02:51:49.551342'),(3,'admin','0001_initial','2019-11-29 02:51:49.982430'),(4,'admin','0002_logentry_remove_auto_add','2019-11-29 02:51:50.071645'),(5,'admin','0003_logentry_add_action_flag_choices','2019-11-29 02:51:50.083802'),(6,'taggit','0001_initial','2019-11-29 02:51:50.149664'),(7,'taggit','0002_auto_20150616_2121','2019-11-29 02:51:50.289810'),(8,'contenttypes','0002_remove_content_type_name','2019-11-29 02:51:50.386723'),(9,'taggit','0003_taggeditem_add_unique_index','2019-11-29 02:51:50.407532'),(10,'article','0001_initial','2019-11-29 02:51:50.443468'),(11,'article','0002_articlepost_total_views','2019-11-29 02:51:50.525525'),(12,'article','0003_auto_20190904_0914','2019-11-29 02:51:50.597337'),(13,'article','0004_articlepost_tags','2019-11-29 02:51:50.650132'),(14,'article','0005_articlepost_avatar','2019-11-29 02:51:50.708547'),(15,'article','0006_articlepost_likes','2019-11-29 02:51:50.762155'),(16,'article','0007_auto_20191014_1132','2019-11-29 02:51:50.825666'),(17,'auth','0002_alter_permission_name_max_length','2019-11-29 02:51:50.888359'),(18,'auth','0003_alter_user_email_max_length','2019-11-29 02:51:50.943976'),(19,'auth','0004_alter_user_username_opts','2019-11-29 02:51:50.956434'),(20,'auth','0005_alter_user_last_login_null','2019-11-29 02:51:51.020844'),(21,'auth','0006_require_contenttypes_0002','2019-11-29 02:51:51.030232'),(22,'auth','0007_alter_validators_add_error_messages','2019-11-29 02:51:51.045208'),(23,'auth','0008_alter_user_username_max_length','2019-11-29 02:51:51.103831'),(24,'auth','0009_alter_user_last_name_max_length','2019-11-29 02:51:51.160816'),(25,'auth','0010_alter_group_name_max_length','2019-11-29 02:51:51.217387'),(26,'auth','0011_update_proxy_permissions','2019-11-29 02:51:51.237723'),(27,'carousel','0001_initial','2019-11-29 02:51:51.267970'),(28,'carousel','0002_carousel_img_link','2019-11-29 02:51:51.303053'),(29,'comment','0001_initial','2019-11-29 02:51:51.340735'),(30,'comment','0002_auto_20190904_2153','2019-11-29 02:51:51.459786'),(31,'comment','0003_auto_20190905_0941','2019-11-29 02:51:51.772433'),(32,'notifications','0001_initial','2019-11-29 02:51:52.538029'),(33,'notifications','0002_auto_20150224_1134','2019-11-29 02:51:53.154569'),(34,'notifications','0003_notification_data','2019-11-29 02:51:53.220409'),(35,'notifications','0004_auto_20150826_1508','2019-11-29 02:51:53.254763'),(36,'notifications','0005_auto_20160504_1520','2019-11-29 02:51:53.277252'),(37,'notifications','0006_indexes','2019-11-29 02:51:53.723744'),(38,'sessions','0001_initial','2019-11-29 02:51:53.837697'),(39,'userprofile','0001_initial','2019-11-29 02:51:54.059598'),(40,'article','0008_articlepost_avatar','2020-04-01 13:38:02.633219');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('01lphykvy7uf8mdt7xirrpvw7j4ykbqz','MmEwMGU2NzgwNjc4NjBiNzhlY2RhMTZjYTI3YjE4NmQzMTEyNGNjZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNjRkYzAxYTRjNDUzMGY1M2Q1ODliNTc1Mjk2MGZmNWY3OGYxNzBhIn0=','2020-01-22 09:28:19.617611'),('37jnyzjt1p0sagm89h9ur0ci558beh1k','MmEwMGU2NzgwNjc4NjBiNzhlY2RhMTZjYTI3YjE4NmQzMTEyNGNjZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNjRkYzAxYTRjNDUzMGY1M2Q1ODliNTc1Mjk2MGZmNWY3OGYxNzBhIn0=','2020-03-05 10:25:47.227839'),('3boyu0d6lnp6hg8cnnd5v7tdrcpsyt9x','MmEwMGU2NzgwNjc4NjBiNzhlY2RhMTZjYTI3YjE4NmQzMTEyNGNjZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNjRkYzAxYTRjNDUzMGY1M2Q1ODliNTc1Mjk2MGZmNWY3OGYxNzBhIn0=','2020-01-18 07:56:32.167867'),('824s3ajs147dyu92rce5uorgkryp77iw','MmEwMGU2NzgwNjc4NjBiNzhlY2RhMTZjYTI3YjE4NmQzMTEyNGNjZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNjRkYzAxYTRjNDUzMGY1M2Q1ODliNTc1Mjk2MGZmNWY3OGYxNzBhIn0=','2019-12-13 02:54:49.142599'),('9zegwca3qjw93ou72b6dojy50pb47ur2','MmEwMGU2NzgwNjc4NjBiNzhlY2RhMTZjYTI3YjE4NmQzMTEyNGNjZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNjRkYzAxYTRjNDUzMGY1M2Q1ODliNTc1Mjk2MGZmNWY3OGYxNzBhIn0=','2020-01-05 11:16:35.085559'),('c4wglq6lrxso0uw8gmf6qr5e2my1m5dm','MmEwMGU2NzgwNjc4NjBiNzhlY2RhMTZjYTI3YjE4NmQzMTEyNGNjZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNjRkYzAxYTRjNDUzMGY1M2Q1ODliNTc1Mjk2MGZmNWY3OGYxNzBhIn0=','2020-03-26 11:03:42.390439'),('i2sfxpor5ubqa60p88aw8om5m2uvxvl5','MmEwMGU2NzgwNjc4NjBiNzhlY2RhMTZjYTI3YjE4NmQzMTEyNGNjZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNjRkYzAxYTRjNDUzMGY1M2Q1ODliNTc1Mjk2MGZmNWY3OGYxNzBhIn0=','2019-12-18 12:06:40.980339'),('iwolkwy3u8essg2wcv9rw7rbo9l67goj','MmEwMGU2NzgwNjc4NjBiNzhlY2RhMTZjYTI3YjE4NmQzMTEyNGNjZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNjRkYzAxYTRjNDUzMGY1M2Q1ODliNTc1Mjk2MGZmNWY3OGYxNzBhIn0=','2020-01-02 08:56:55.863747'),('k3zb4g033wdgwuwuk3syyofze62z45bb','MmEwMGU2NzgwNjc4NjBiNzhlY2RhMTZjYTI3YjE4NmQzMTEyNGNjZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNjRkYzAxYTRjNDUzMGY1M2Q1ODliNTc1Mjk2MGZmNWY3OGYxNzBhIn0=','2020-04-13 04:59:43.240809'),('kx2ota4objsi6zn00mbsi17jk3ldf94e','MmEwMGU2NzgwNjc4NjBiNzhlY2RhMTZjYTI3YjE4NmQzMTEyNGNjZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNjRkYzAxYTRjNDUzMGY1M2Q1ODliNTc1Mjk2MGZmNWY3OGYxNzBhIn0=','2019-12-13 10:32:00.479936'),('ky3uyqld12i3hnknrh7ejvssvb4u39wf','MmEwMGU2NzgwNjc4NjBiNzhlY2RhMTZjYTI3YjE4NmQzMTEyNGNjZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNjRkYzAxYTRjNDUzMGY1M2Q1ODliNTc1Mjk2MGZmNWY3OGYxNzBhIn0=','2020-04-17 13:17:16.115453'),('mqyyin4cr6our4x3eqppm10sybekfl7p','NTQxMTMxY2I2YjBiMjA0NWE1NGZhM2U0NjNlNDRkNDk2ZjgxODI0Mzp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI0ZTlhOTk5YzU3YjI3YjUyMzc5MDgzYTc0ZjMxZWQzYmIxZWE5YzcwIn0=','2020-01-01 12:11:17.940852'),('wtug9879eesd0nbqw04214tj0zs8l2rc','MmEwMGU2NzgwNjc4NjBiNzhlY2RhMTZjYTI3YjE4NmQzMTEyNGNjZjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNjRkYzAxYTRjNDUzMGY1M2Q1ODliNTc1Mjk2MGZmNWY3OGYxNzBhIn0=','2020-01-02 00:44:13.012325');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications_notification`
--

DROP TABLE IF EXISTS `notifications_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` varchar(20) NOT NULL,
  `unread` tinyint(1) NOT NULL,
  `actor_object_id` varchar(255) NOT NULL,
  `verb` varchar(255) NOT NULL,
  `description` longtext,
  `target_object_id` varchar(255) DEFAULT NULL,
  `action_object_object_id` varchar(255) DEFAULT NULL,
  `timestamp` datetime(6) NOT NULL,
  `public` tinyint(1) NOT NULL,
  `action_object_content_type_id` int(11) DEFAULT NULL,
  `actor_content_type_id` int(11) NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `target_content_type_id` int(11) DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL,
  `emailed` tinyint(1) NOT NULL,
  `data` longtext,
  PRIMARY KEY (`id`),
  KEY `notifications_notifi_action_object_conten_7d2b8ee9_fk_django_co` (`action_object_content_type_id`),
  KEY `notifications_notifi_actor_content_type_i_0c69d7b7_fk_django_co` (`actor_content_type_id`),
  KEY `notifications_notification_recipient_id_d055f3f0_fk_auth_user_id` (`recipient_id`),
  KEY `notifications_notifi_target_content_type__ccb24d88_fk_django_co` (`target_content_type_id`),
  KEY `notifications_notification_deleted_b32b69e6` (`deleted`),
  KEY `notifications_notification_emailed_23a5ad81` (`emailed`),
  KEY `notifications_notification_public_1bc30b1c` (`public`),
  KEY `notifications_notification_unread_cce4be30` (`unread`),
  CONSTRAINT `notifications_notifi_action_object_conten_7d2b8ee9_fk_django_co` FOREIGN KEY (`action_object_content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `notifications_notifi_actor_content_type_i_0c69d7b7_fk_django_co` FOREIGN KEY (`actor_content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `notifications_notifi_target_content_type__ccb24d88_fk_django_co` FOREIGN KEY (`target_content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `notifications_notification_recipient_id_d055f3f0_fk_auth_user_id` FOREIGN KEY (`recipient_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications_notification`
--

LOCK TABLES `notifications_notification` WRITE;
/*!40000 ALTER TABLE `notifications_notification` DISABLE KEYS */;
INSERT INTO `notifications_notification` VALUES (1,'info',0,'2','回复了你',NULL,'6','8','2019-12-18 12:14:06.081468',1,12,7,1,2,0,0,NULL),(2,'info',0,'2','回复了你',NULL,'6','9','2019-12-18 12:14:15.162530',1,12,7,1,2,0,0,NULL),(3,'info',0,'2','回复了你',NULL,'5','10','2019-12-18 12:16:21.094681',1,12,7,1,2,0,0,NULL),(4,'info',0,'3','回复了你',NULL,'6','11','2019-12-19 05:13:38.599968',1,12,7,1,2,0,0,NULL),(5,'info',0,'3','回复了你',NULL,'6','12','2019-12-19 05:13:53.553312',1,12,7,1,2,0,0,NULL);
/*!40000 ALTER TABLE `notifications_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggit_tag`
--

DROP TABLE IF EXISTS `taggit_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggit_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggit_tag`
--

LOCK TABLES `taggit_tag` WRITE;
/*!40000 ALTER TABLE `taggit_tag` DISABLE KEYS */;
INSERT INTO `taggit_tag` VALUES (1,'旅游',''),(2,'mysql','mysql'),(4,'总结','_1'),(6,'读书','_2'),(8,'经验','_3'),(9,'docker','docker'),(10,'linux','linux'),(11,'algorithm','algorithm'),(12,'python','python'),(14,'数据结构','_4');
/*!40000 ALTER TABLE `taggit_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggit_taggeditem`
--

DROP TABLE IF EXISTS `taggit_taggeditem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggit_taggeditem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_id` int(11) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `taggit_taggeditem_content_type_id_object_id_tag_id_4bb97a8e_uniq` (`content_type_id`,`object_id`,`tag_id`),
  KEY `taggit_taggeditem_tag_id_f4f5b767_fk_taggit_tag_id` (`tag_id`),
  KEY `taggit_taggeditem_object_id_e2d7d1df` (`object_id`),
  KEY `taggit_taggeditem_content_type_id_object_id_196cc965_idx` (`content_type_id`,`object_id`),
  CONSTRAINT `taggit_taggeditem_content_type_id_9957a03c_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `taggit_taggeditem_tag_id_f4f5b767_fk_taggit_tag_id` FOREIGN KEY (`tag_id`) REFERENCES `taggit_tag` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggit_taggeditem`
--

LOCK TABLES `taggit_taggeditem` WRITE;
/*!40000 ALTER TABLE `taggit_taggeditem` DISABLE KEYS */;
INSERT INTO `taggit_taggeditem` VALUES (13,1,2,1),(50,2,2,2),(65,4,2,2),(36,5,2,4),(35,6,2,6),(84,7,2,8),(46,8,2,9),(40,9,2,10),(63,10,2,10),(56,11,2,2),(55,11,2,10),(61,12,2,11),(66,13,2,12),(71,14,2,11),(72,15,2,11),(75,16,2,12),(76,16,2,14),(89,17,2,12);
/*!40000 ALTER TABLE `taggit_taggeditem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userprofile_profile`
--

DROP TABLE IF EXISTS `userprofile_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userprofile_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(20) NOT NULL,
  `avatar` varchar(100) NOT NULL,
  `bio` longtext NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `userprofile_profile_user_id_f37c6bb1_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userprofile_profile`
--

LOCK TABLES `userprofile_profile` WRITE;
/*!40000 ALTER TABLE `userprofile_profile` DISABLE KEYS */;
INSERT INTO `userprofile_profile` VALUES (1,'15585114842','','不填个人信息 不得行',1);
/*!40000 ALTER TABLE `userprofile_profile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-03 23:50:01
